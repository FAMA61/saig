import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/** اللاعب — لا يوجد تسجيل دخول، لذلك نستخدم لاعبًا افتراضيًا واحدًا في هذا العرض التجريبي. */
export const players = pgTable("players", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  points: integer("points").notNull().default(0),
  lessonsDone: integer("lessons_done").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

/** تقدّم الدروس + أفضل نتيجة في الاختبار لكل درس. */
export const lessonProgress = pgTable(
  "lesson_progress",
  {
    id: serial("id").primaryKey(),
    playerId: text("player_id").notNull(),
    lessonId: text("lesson_id").notNull(),
    bestPct: integer("best_pct").notNull().default(0),
    attempts: integer("attempts").notNull().default(0),
    completed: boolean("completed").notNull().default(false),
    pointAwarded: boolean("point_awarded").notNull().default(false),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("lesson_progress_player_lesson_uq").on(t.playerId, t.lessonId)],
);

/** سجل النقاط — كل نقطة لها سبب (درس/اختبار/إنجاز). */
export const pointsLedger = pgTable("points_ledger", {
  id: serial("id").primaryKey(),
  playerId: text("player_id").notNull(),
  amount: integer("amount").notNull().default(1),
  reason: text("reason").notNull(),
  refId: text("ref_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

/** الخانات المفتوحة في المرآب — تُفتح خانة كل 10 نقاط. */
export const unlockedRewards = pgTable(
  "unlocked_rewards",
  {
    id: serial("id").primaryKey(),
    playerId: text("player_id").notNull(),
    tier: integer("tier").notNull(),
    carName: text("car_name").notNull(),
    unlockedAt: timestamp("unlocked_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [uniqueIndex("unlocked_rewards_player_tier_uq").on(t.playerId, t.tier)],
);

/** لوحة نتائج لعبة الشارع. */
export const gameScores = pgTable("game_scores", {
  id: serial("id").primaryKey(),
  playerId: text("player_id").notNull(),
  playerName: text("player_name").notNull(),
  score: integer("score").notNull(),
  distance: integer("distance").notNull().default(0),
  tokens: integer("tokens").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Player = typeof players.$inferSelect;
export type LessonProgressRow = typeof lessonProgress.$inferSelect;
export type GameScoreRow = typeof gameScores.$inferSelect;
export type UnlockedRewardRow = typeof unlockedRewards.$inferSelect;
