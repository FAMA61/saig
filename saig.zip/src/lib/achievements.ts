/** اختبارات القيادة — مصادر النقاط داخل لعبة الشارع. كل مستوى مكتمل = نقطة واحدة. */
export type RunStats = {
  score: number;
  distance: number;
  tokens: number;
  seconds: number;
};

export type Achievement = {
  id: string;
  label: string;
  stat: keyof RunStats;
  tiers: number[];
  unit: string;
};

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: "control",
    label: "اختبار السيطرة على السرعة",
    stat: "score",
    tiers: [1200, 4200, 9000],
    unit: "نقطة",
  },
  {
    id: "distance",
    label: "اختبار المسافة الآمنة",
    stat: "distance",
    tiers: [500, 1400, 3200],
    unit: "متر",
  },
  {
    id: "signs",
    label: "اختبار قراءة اللافتات",
    stat: "tokens",
    tiers: [8, 18, 32],
    unit: "لافتة",
  },
  {
    id: "endurance",
    label: "اختبار الثبات خلف المقود",
    stat: "seconds",
    tiers: [40, 90, 160],
    unit: "ثانية",
  },
];

export function evaluateRun(run: RunStats): string[] {
  const earned: string[] = [];
  for (const a of ACHIEVEMENTS) {
    const value = run[a.stat];
    a.tiers.forEach((threshold, i) => {
      if (value >= threshold) earned.push(`${a.id}:${i + 1}`);
    });
  }
  return earned;
}

export function describeEarned(keys: string[]) {
  return keys.map((k) => {
    const [id, tier] = k.split(":");
    const a = ACHIEVEMENTS.find((x) => x.id === id);
    return {
      key: k,
      label: a ? `${a.label} — المستوى ${tier}` : k,
      threshold: a ? `${a.tiers[Number(tier) - 1]} ${a.unit}` : "",
    };
  });
}

export type PointsEvent = {
  points: number;
  newUnlocks: { tier: number; carName: string }[];
  awarded: string[];
};

export const POINTS_EVENT = "garage:points-update";

export function emitPoints(e: PointsEvent) {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent<PointsEvent>(POINTS_EVENT, { detail: e }));
  }
}
