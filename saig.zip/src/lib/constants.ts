/** ثوابت مشتركة بين الواجهة والخادم — لا تستورد قاعدة البيانات. */
export const POINTS_PER_GARAGE_SLOT = 10;
export const GARAGE_SLOTS = 6;

export const CARS = [
  { name: "كوبيه أسود ليلي", tag: "GT Coupé", power: "612 حصان" },
  { name: "كابريوليه فضي", tag: "Roadster", power: "503 حصان" },
  { name: "برتقالي رياضي", tag: "Super Sport", power: "720 حصان" },
  { name: "سيدان فاخرة", tag: "Grand Saloon", power: "480 حصان" },
  { name: "سيارة سباق حمراء", tag: "Track Edition", power: "830 حصان" },
  { name: "الأسطورة الذهبية", tag: "The Finale", power: "1001 حصان" },
];
