import { db } from "@/db";
import { gameScores, lessonProgress, pointsLedger, players, unlockedRewards } from "@/db/schema";
import { asc, desc, eq, and, inArray } from "drizzle-orm";
import type { LessonProgressRow, UnlockedRewardRow } from "@/db/schema";
import { LESSONS, TOTAL_LESSONS } from "@/lib/lessons";
import { CARS, GARAGE_SLOTS, POINTS_PER_GARAGE_SLOT } from "@/lib/constants";

export const DEFAULT_PLAYER_ID = "driver-1";

export { CARS, GARAGE_SLOTS, POINTS_PER_GARAGE_SLOT } from "@/lib/constants";

/** كل 10 نقاط تفتح خانة مرآب جديدة. */

export async function ensurePlayer() {
  const existing = await db.query.players.findFirst({
    where: eq(players.id, DEFAULT_PLAYER_ID),
  });
  if (existing) return existing;
  const [created] = await db
    .insert(players)
    .values({ id: DEFAULT_PLAYER_ID, name: "سائق المستقبل", points: 0 })
    .returning();
  return created;
}

export async function getState() {
  const player = await ensurePlayer();
  const progress = await db.query.lessonProgress.findMany({
    where: eq(lessonProgress.playerId, DEFAULT_PLAYER_ID),
  });
  const rewards = await db.query.unlockedRewards.findMany({
    where: eq(unlockedRewards.playerId, DEFAULT_PLAYER_ID),
    orderBy: [asc(unlockedRewards.tier)],
  });
  const topScores = await db.query.gameScores.findMany({
    orderBy: [desc(gameScores.score), desc(gameScores.id)],
    limit: 8,
  });
  return { player, progress, rewards, topScores };
}

export async function recordLessonResult(lessonId: string, correct: number, total: number) {
  await ensurePlayer();
  const pct = Math.round((correct / total) * 100);
  // شرط النقاط المعلن: أعلى من 95%
  const passed = pct > 95;

  const existing = await db.query.lessonProgress.findFirst({
    where: and(eq(lessonProgress.playerId, DEFAULT_PLAYER_ID), eq(lessonProgress.lessonId, lessonId)),
  });

  let pointAwarded = false;
  if (existing) {
    const best = Math.max(existing.bestPct, pct);
    await db
      .update(lessonProgress)
      .set({
        bestPct: best,
        attempts: existing.attempts + 1,
        completed: existing.completed || passed,
        pointAwarded: existing.pointAwarded || passed,
        updatedAt: new Date(),
      })
      .where(eq(lessonProgress.id, existing.id));
    pointAwarded = passed && !existing.pointAwarded;
  } else {
    await db.insert(lessonProgress).values({
      playerId: DEFAULT_PLAYER_ID,
      lessonId,
      bestPct: pct,
      attempts: 1,
      completed: passed,
      pointAwarded: passed,
    });
    pointAwarded = passed;
  }

  if (pointAwarded) {
    await db.insert(pointsLedger).values({
      playerId: DEFAULT_PLAYER_ID,
      amount: 1,
      reason: "lesson_mastered",
      refId: lessonId,
    });
  }

  const player = await ensurePlayer();
  const newPoints = player.points + (pointAwarded ? 1 : 0);
  const lessonsDone = Math.max(
    player.lessonsDone,
    (await db.query.lessonProgress.findMany({ where: eq(lessonProgress.playerId, DEFAULT_PLAYER_ID) }))
      .filter((p: LessonProgressRow) => p.completed).length,
  );

  await db
    .update(players)
    .set({ points: newPoints, lessonsDone })
    .where(eq(players.id, DEFAULT_PLAYER_ID));

  const unlocked = await unlockGarageSlots(newPoints);

  return {
    pct,
    passed,
    pointAwarded,
    points: newPoints,
    lessonsDone,
    unlocked,
    allComplete: lessonsDone >= TOTAL_LESSONS,
  };
}

export async function unlockGarageSlots(points: number) {
  const available = Math.min(GARAGE_SLOTS, Math.floor(points / POINTS_PER_GARAGE_SLOT));
  const already = await db.query.unlockedRewards.findMany({
    where: eq(unlockedRewards.playerId, DEFAULT_PLAYER_ID),
    orderBy: [asc(unlockedRewards.tier)],
  });
  const have = new Set(already.map((r: UnlockedRewardRow) => r.tier));
  const fresh: { tier: number; carName: string }[] = [];
  for (let tier = 1; tier <= available; tier++) {
    if (have.has(tier)) continue;
    const car = CARS[tier - 1];
    await db
      .insert(unlockedRewards)
      .values({ playerId: DEFAULT_PLAYER_ID, tier, carName: car.name })
      .onConflictDoNothing();
    fresh.push({ tier, carName: car.name });
  }
  return fresh;
}

export async function submitGameScore(input: {
  playerName: string;
  score: number;
  distance: number;
  tokens: number;
}) {
  await ensurePlayer();
  const [row] = await db
    .insert(gameScores)
    .values({
      playerId: DEFAULT_PLAYER_ID,
      playerName: input.playerName.slice(0, 24) || "سائق",
      score: Math.max(0, Math.round(input.score)),
      distance: Math.max(0, Math.round(input.distance)),
      tokens: Math.max(0, Math.round(input.tokens)),
    })
    .returning();
  return row;
}

/** تسجيل إنجازات اختبار القيادة — كل مستوى مكتمل يمنح نقطة واحدة (مرة واحدة). */
export async function awardDrivePoints(earned: string[]) {
  await ensurePlayer();
  const unique = Array.from(new Set(earned)).filter((k) => /^[a-z]+:[1-9]$/.test(k));
  let awarded: string[] = [];
  if (unique.length) {
    const existing = await db
      .select({ refId: pointsLedger.refId })
      .from(pointsLedger)
      .where(
        and(
          eq(pointsLedger.playerId, DEFAULT_PLAYER_ID),
          eq(pointsLedger.reason, "drive_test"),
          inArray(pointsLedger.refId, unique),
        ),
      );
    const have = new Set(existing.map((r) => r.refId));
    awarded = unique.filter((k) => !have.has(k));
    if (awarded.length) {
      await db.insert(pointsLedger).values(
        awarded.map((k) => ({
          playerId: DEFAULT_PLAYER_ID,
          amount: 1,
          reason: "drive_test",
          refId: k,
        })),
      );
    }
  }

  const player = await ensurePlayer();
  const points = (player?.points ?? 0) + awarded.length;
  await db.update(players).set({ points }).where(eq(players.id, DEFAULT_PLAYER_ID));
  const newUnlocks = await unlockGarageSlots(points);
  return { points, awarded, newUnlocks };
}

export async function topScores(limit = 8) {
  return db.query.gameScores.findMany({
    orderBy: [desc(gameScores.score), desc(gameScores.id)],
    limit,
  });
}

export const TOTAL_LESSONS_COUNT = TOTAL_LESSONS;
export const ALL_LESSONS = LESSONS;
