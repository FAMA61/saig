const CODE_STATE = `// ── منطق الحالة (State Management Logic) ─────────────────────────
const POINT_THRESHOLD = 95;              // أي نتيجة أعلى من 95% = نقطة واحدة
const POINTS_PER_GARAGE_SLOT = 10;       // كل 10 نقاط تفتح خانة مرآب

function onLessonFinished(quiz, progress, points) {
  const pct = Math.round((quiz.correct / quiz.total) * 100);

  // 1) هل تحقّق الشرط؟ (>95%)
  const passed = pct > POINT_THRESHOLD;

  // 2) النقطة تُمنح مرة واحدة لكل درس (منع التكرار)
  const isNewBest = pct > (progress.bestPct ?? 0);
  const pointAwarded = passed && !progress.pointAwarded;

  // 3) تحديث التقدّم
  progress = {
    ...progress,
    bestPct:  Math.max(progress.bestPct ?? 0, pct),
    attempts: (progress.attempts ?? 0) + 1,
    completed: progress.completed || passed,
    pointAwarded: progress.pointAwarded || passed,
  };

  if (pointAwarded) points += 1;

  // 4) فتح خانة المرآب كل 10 نقاط
  const unlockedTier = Math.floor(points / POINTS_PER_GARAGE_SLOT);
  const garageSlots = Array.from({ length: unlockedTier }, (_, i) => CARS[i]);

  // 5) المشهد الختامي: كل الدروس مكتملة بنجاح
  const allComplete = progress.allLessons.every((p) => p.completed);

  return { pct, passed, pointAwarded, points, garageSlots, allComplete, isNewBest };
}`;

const CODE_SCHEMA = `-- ── هيكلية قاعدة البيانات (PostgreSQL / Drizzle) ────────────────
CREATE TABLE players (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  points        INTEGER NOT NULL DEFAULT 0,
  lessons_done  INTEGER NOT NULL DEFAULT 0,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE lesson_progress (
  id            SERIAL PRIMARY KEY,
  player_id     TEXT NOT NULL REFERENCES players(id),
  lesson_id     TEXT NOT NULL,
  best_pct      INTEGER NOT NULL DEFAULT 0,
  attempts      INTEGER NOT NULL DEFAULT 0,
  completed     BOOLEAN NOT NULL DEFAULT FALSE,
  point_awarded BOOLEAN NOT NULL DEFAULT FALSE,
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (player_id, lesson_id)      -- صف واحد لكل درس لكل لاعب
);

CREATE TABLE points_ledger (
  id         SERIAL PRIMARY KEY,
  player_id  TEXT NOT NULL REFERENCES players(id),
  amount     INTEGER NOT NULL DEFAULT 1,
  reason     TEXT NOT NULL,           -- 'lesson_mastered' | 'challenge' | 'bonus'
  ref_id     TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE unlocked_rewards (
  id          SERIAL PRIMARY KEY,
  player_id   TEXT NOT NULL REFERENCES players(id),
  tier        INTEGER NOT NULL,        -- رقم الخانة في المرآب
  car_name    TEXT NOT NULL,
  unlocked_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (player_id, tier)
);

CREATE TABLE game_scores (
  id          SERIAL PRIMARY KEY,
  player_id   TEXT NOT NULL REFERENCES players(id),
  player_name TEXT NOT NULL,
  score       INTEGER NOT NULL,
  distance    INTEGER NOT NULL DEFAULT 0,
  tokens      INTEGER NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX game_scores_rank_idx ON game_scores (score DESC);`;

const CODE_FLUTTER = `// ── شاشة "السيارة الفخمة" + الحوار التفاعلي (Flutter) ───────────
class LuxuryCarScreen extends StatefulWidget {
  final int points;
  final bool allComplete;
  const LuxuryCarScreen({super.key, required this.points, required this.allComplete});

  @override
  State<LuxuryCarScreen> createState() => _LuxuryCarScreenState();
}

class _LuxuryCarScreenState extends State<LuxuryCarScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this, duration: const Duration(milliseconds: 900))..forward();

  String _dialog = '';
  bool _answered = false;

  @override
  void initState() {
    super.initState();
    // النص يتغيّر حسب عدد النقاط ومدى الإكمال
    _type(widget.allComplete
        ? 'أراك أتممتَ كل الدروس... إذًا، هل أنت ستسوقني؟'
        : 'هل أنت ستسوقني؟');
  }

  Future<void> _type(String text) async {
    setState(() => _dialog = '');
    for (int i = 1; i <= text.length; i++) {
      await Future.delayed(const Duration(milliseconds: 30));
      if (mounted) setState(() => _dialog = text.substring(0, i));
    }
  }

  int get _tier => widget.points ~/ 10;          // فتح خانة كل 10 نقاط

  @override
  Widget build(BuildContext context) {
    final car = GarageCars.all[_tier.clamp(0, GarageCars.all.length - 1)];
    return Scaffold(
      backgroundColor: const Color(0xFF12151A),
      body: Stack(children: [
        // السيارة مع تأثير ظهور من الظل
        FadeTransition(
          opacity: CurvedAnimation(parent: _c, curve: Curves.easeOut),
          child: ScaleTransition(
            scale: Tween(begin: 0.92, end: 1.0)
                .animate(CurvedAnimation(parent: _c, curve: Curves.easeOutBack)),
            child: Image.asset(car.image, fit: BoxFit.cover, width: double.infinity),
          ),
        ),
        Positioned(
          bottom: 24, left: 24, right: 24,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(car.name, style: const TextStyle(
              color: Color(0xFFF2B705), fontSize: 32, fontFamily: 'Amiri')),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white12),
              ),
              child: Text(_dialog, style: const TextStyle(
                color: Color(0xFFF2B705), fontSize: 22, fontFamily: 'Amiri')),
            ),
            const SizedBox(height: 16),
            if (!_answered) Row(children: [
              FilledButton(
                onPressed: () {
                  setState(() => _answered = true);
                  _type(widget.allComplete
                      ? 'نعم! أنت ستسوقني أيها السائق المحترف الذي ليس منك اثنان!'
                      : 'شجاعة جميلة... أنهِ الدروس أولًا، وسأكون لك.');
                },
                child: const Text('نعم، سأقودك بإتقان'),
              ),
              const SizedBox(width: 12),
              OutlinedButton(
                onPressed: () => setState(() => _answered = true),
                child: const Text('لستّ مستعدًا بعد'),
              ),
            ]),
          ]),
        ),
      ]),
    );
  }
}`;

function Code({ label, code }: { label: string; code: string }) {
  return (
    <figure className="overflow-hidden rounded-[18px] border border-white/10 bg-[#0F1318]">
      <figcaption className="flex items-center justify-between border-b border-white/10 px-5 py-3">
        <span className="tracked text-[9px] text-road-yellow">{label}</span>
        <span className="tnum text-[10px] text-paper/40">{code.split("\n").length} سطرًا</span>
      </figcaption>
      <pre
        dir="ltr"
        className="overflow-x-auto px-5 py-5 text-left font-mono text-[11.5px] leading-6 text-[#CFE3D2]"
      >
        <code>{code}</code>
      </pre>
    </figure>
  );
}

export default function Docs() {
  return (
    <section id="docs" className="relative">
      <div className="grid gap-10 lg:grid-cols-[1fr_320px]">
        <div>
          <div className="tracked text-[10px] text-warm-2">التوثيق التقني · Engineering Notes</div>
          <h2 className="mt-2 font-display text-5xl leading-[1.15] text-ink sm:text-6xl">
            المنطق البرمجي والكود
          </h2>
          <p className="mt-4 max-w-2xl text-[15px] leading-8 text-warm-2">
            هذا التطبيق مبني كنسخة ويب كاملة (Next.js + PostgreSQL + Drizzle) لتجربة كل
            الميكانيكيات فعليًا. أما نسخة الهاتف الإنتاجية فالتوصية بها أدناه.
          </p>

          <div className="mt-8 space-y-6">
            <Code label="1 · منطق إدارة الحالة" code={CODE_STATE} />
            <Code label="2 · هيكلية قاعدة البيانات" code={CODE_SCHEMA} />
            <Code label="3 · شاشة السيارة الفخمة — Flutter" code={CODE_FLUTTER} />
          </div>
        </div>

        <aside className="space-y-4 lg:sticky lg:top-6 lg:h-fit">
          <div className="rounded-[20px] border border-ink/12 bg-ink p-6 text-paper">
            <div className="tracked text-[9px] text-road-yellow">التوصية التقنية</div>
            <h3 className="mt-2 font-display text-2xl leading-snug">
              Flutter 3 + Rive + Riverpod
            </h3>
            <ul className="mt-4 space-y-3 text-[12px] leading-6 text-paper/75">
              <li>
                <strong className="text-road-yellow">Flutter 3</strong> — أداء 60/120fps، ودعم RTL
                ممتاز للعربية، وبناء واحد لنظامي iOS/Android.
              </li>
              <li>
                <strong className="text-road-yellow">Rive</strong> — سيارات وحوارات متحركة
                تفاعلية أخفّ من Lottie ويمكن التحكّم بها بالحالة (State Machine).
              </li>
              <li>
                <strong className="text-road-yellow">Riverpod</strong> — إدارة حالة قابلة
                للاختبار: `LessonProgress`, `PointsController`, `GarageController`.
              </li>
              <li>
                <strong className="text-road-yellow">Drift + Supabase</strong> — تخزين محلي
                (Offline-first) ومزامنة مع الخادم.
              </li>
            </ul>
          </div>

          <div className="rounded-[20px] border border-ink/12 bg-paper-2/60 p-6">
            <div className="tracked text-[9px] text-warm-2">حزمة الرسوم</div>
            <table className="mt-3 w-full text-[11.5px]">
              <tbody className="[&_td]:border-b [&_td]:border-ink/10 [&_td]:py-2">
                <tr>
                  <td className="text-warm-2">Rive</td>
                  <td className="tnum text-left">سيارات + حوارات</td>
                </tr>
                <tr>
                  <td className="text-warm-2">Lottie</td>
                  <td className="tnum text-left">انتقالات + مكافآت</td>
                </tr>
                <tr>
                  <td className="text-warm-2">Flame</td>
                  <td className="tnum text-left">محرّك لعبة الشارع</td>
                </tr>
                <tr>
                  <td className="text-warm-2">Confetti</td>
                  <td className="tnum text-left">المشهد الختامي</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="rounded-[20px] border border-ink/12 bg-paper-2/60 p-6">
            <div className="tracked text-[9px] text-warm-2">واجهات الخادم</div>
            <ul className="mt-3 space-y-2 font-mono text-[11px] text-ink" dir="ltr">
              <li className="rounded-lg bg-ink/8 px-3 py-2">GET /api/state</li>
              <li className="rounded-lg bg-ink/8 px-3 py-2">POST /api/lesson-result</li>
              <li className="rounded-lg bg-ink/8 px-3 py-2">GET /api/scores</li>
              <li className="rounded-lg bg-ink/8 px-3 py-2">POST /api/scores</li>
              <li className="rounded-lg bg-ink/8 px-3 py-2">GET /api/health</li>
            </ul>
          </div>
        </aside>
      </div>
    </section>
  );
}
