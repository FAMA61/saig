"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Sign } from "@/components/Signs";
import { LESSONS, POINT_THRESHOLD, type Lesson, type Question } from "@/lib/lessons";
import { CARS, GARAGE_SLOTS, POINTS_PER_GARAGE_SLOT } from "@/lib/constants";
import { POINTS_EVENT, type PointsEvent } from "@/lib/achievements";

type ProgressRow = {
  lessonId: string;
  bestPct: number;
  attempts: number;
  completed: boolean;
  pointAwarded: boolean;
};

type RewardRow = { tier: number; carName: string };

export type InitialState = {
  points: number;
  lessonsDone: number;
  progress: ProgressRow[];
  rewards: RewardRow[];
};

function useTypewriter(text: string, speed = 26, active = true) {
  const [out, setOut] = useState("");
  useEffect(() => {
    if (!active) {
      setOut("");
      return;
    }
    setOut("");
    let i = 0;
    const id = window.setInterval(() => {
      i += 1;
      setOut(text.slice(0, i));
      if (i >= text.length) window.clearInterval(id);
    }, speed);
    return () => window.clearInterval(id);
  }, [text, speed, active]);
  return out;
}

export default function Learn({ initial }: { initial: InitialState }) {
  const [points, setPoints] = useState(initial.points);
  const [lessonsDone, setLessonsDone] = useState(initial.lessonsDone);
  const [progress, setProgress] = useState<Record<string, ProgressRow>>(
    Object.fromEntries(initial.progress.map((p) => [p.lessonId, p])),
  );
  const [rewards, setRewards] = useState<RewardRow[]>(initial.rewards);
  const [active, setActive] = useState<Lesson | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [result, setResult] = useState<null | {
    pct: number;
    correct: number;
    total: number;
    passed: boolean;
    pointAwarded: boolean;
    newUnlocks: { tier: number; carName: string }[];
  }>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [garageTier, setGarageTier] = useState<number | null>(null);
  const [finale, setFinale] = useState(false);
  const finaleShown = useRef(false);
  const quizRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(null), 3600);
    return () => window.clearTimeout(id);
  }, [toast]);

  // نقاط تُكتسب من لعبة الشارع (اختبارات القيادة) — تحديث حيّ دون إعادة تحميل
  useEffect(() => {
    const handler = (e: Event) => {
      const d = (e as CustomEvent<PointsEvent>).detail;
      if (!d) return;
      setPoints(d.points);
      if (d.newUnlocks?.length) {
        setRewards((r) => [...r, ...d.newUnlocks.map((u) => ({ tier: u.tier, carName: u.carName }))]);
        setGarageTier(d.newUnlocks[0].tier);
      }
      if (d.awarded?.length) setToast(`+${d.awarded.length} نقطة من اختبار القيادة`);
    };
    window.addEventListener(POINTS_EVENT, handler);
    return () => window.removeEventListener(POINTS_EVENT, handler);
  }, []);

  useEffect(() => {
    if (lessonsDone >= LESSONS.length && !finaleShown.current) {
      finaleShown.current = true;
      const id = window.setTimeout(() => setFinale(true), 900);
      return () => window.clearTimeout(id);
    }
  }, [lessonsDone]);

  const startLesson = (l: Lesson) => {
    setActive(l);
    setAnswers([]);
    setResult(null);
    window.setTimeout(() => quizRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
  };

  const answer = (qIndex: number, optionIndex: number) => {
    setAnswers((prev) => {
      const next = [...prev];
      next[qIndex] = optionIndex;
      return next;
    });
  };

  const submitQuiz = useCallback(async () => {
    if (!active) return;
    const correct = active.questions.reduce(
      (acc, q, i) => acc + (answers[i] === q.a ? 1 : 0),
      0,
    );
    const total = active.questions.length;
    const pct = Math.round((correct / total) * 100);
    const passed = pct > POINT_THRESHOLD;

    let serverPoints = points;
    let newUnlocks: { tier: number; carName: string }[] = [];
    let pointAwarded = false;
    try {
      const res = await fetch("/api/lesson-result", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lessonId: active.id, correct, total }),
      });
      const data = await res.json();
      if (!data.error) {
        serverPoints = data.points;
        pointAwarded = !!data.pointAwarded;
        newUnlocks = data.unlocked ?? [];
        setPoints(data.points);
        setLessonsDone(data.lessonsDone);
        setProgress((p) => ({
          ...p,
          [active.id]: {
            lessonId: active.id,
            bestPct: Math.max(p[active.id]?.bestPct ?? 0, pct),
            attempts: (p[active.id]?.attempts ?? 0) + 1,
            completed: (p[active.id]?.completed ?? false) || passed,
            pointAwarded: (p[active.id]?.pointAwarded ?? false) || passed,
          },
        }));
        if (newUnlocks.length) {
          setRewards((r) => [
            ...r,
            ...newUnlocks.map((u) => ({ tier: u.tier, carName: u.carName })),
          ]);
        }
      }
    } catch {
      /* يعمل التطبيق حتى بدون خادم */
    }

    setResult({ pct, correct, total, passed, pointAwarded, newUnlocks });
    if (pointAwarded) setToast(`+1 نقطة · إتقان درس «${active.title}»`);
    else if (passed) setToast("درجة ممتازة — لكن النقطة سُجّلت لهذا الدرس من قبل");
    else setToast(`تحتاج أعلى من ${POINT_THRESHOLD}% لكسب النقطة`);
    if (newUnlocks.length) {
      window.setTimeout(() => setGarageTier(newUnlocks[0].tier), 1200);
    }
    if (serverPoints !== points) setPoints(serverPoints);
  }, [active, answers, points]);

  const unlockedTiers = useMemo(() => new Set(rewards.map((r) => r.tier)), [rewards]);
  const nextTier = Math.min(GARAGE_SLOTS, Math.floor(points / POINTS_PER_GARAGE_SLOT) + 1);
  const pointsToNext = Math.max(0, nextTier * POINTS_PER_GARAGE_SLOT - points);
  const pctToNext = Math.min(100, (points / (nextTier * POINTS_PER_GARAGE_SLOT)) * 100);

  return (
    <div className="relative">
      <div className="grid gap-10 lg:grid-cols-[1fr_260px]">
        {/* ── المحتوى ── */}
        <div>
          {/* المكتبة */}
          <header className="mb-8">
            <div className="tracked text-[10px] text-warm-2">المكتبة · 6 دروس · 30 سؤالًا</div>
            <h2 className="mt-2 font-display text-5xl leading-[1.15] text-ink sm:text-6xl">
              الدروس والاختبارات
            </h2>
            <p className="mt-4 max-w-2xl text-[15px] leading-8 text-warm-2">
              كل درس يشرح قاعدة حقيقية من قوانين المرور، يليه اختبار من خمسة أسئلة. أي درس
              تُجتازه بنسبة <strong className="text-ink">أعلى من {POINT_THRESHOLD}%</strong> يمنحك{" "}
              <strong className="text-ink">نقطة واحدة</strong> تُضاف إلى مرآبك.
            </p>
          </header>

          <div className="grid gap-5 sm:grid-cols-2">
            {LESSONS.map((l) => {
              const p = progress[l.id];
              return (
                <article
                  key={l.id}
                  className="group relative overflow-hidden rounded-[20px] border border-ink/12 bg-paper-2/60 p-6 transition hover:-translate-y-1 hover:border-ink/25 hover:shadow-[0_28px_60px_-32px_rgba(21,24,27,0.55)]"
                >
                  <div className="flex items-start gap-4">
                    <div className="shrink-0 rounded-2xl bg-paper p-2 shadow-[0_10px_24px_-14px_rgba(21,24,27,0.5)]">
                      <Sign kind={l.sign} size={58} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="tracked text-[9px] text-warm-2">{l.unit}</div>
                      <h3 className="mt-1 font-display text-2xl leading-snug text-ink">{l.title}</h3>
                      <p className="mt-2 text-[13.5px] leading-7 text-warm-2">{l.summary}</p>
                    </div>
                  </div>

                  <div className="mt-5 flex items-center gap-3">
                    <div className="flex-1">
                      <div className="h-2 w-full overflow-hidden rounded-full bg-ink/10">
                        <div
                          className="h-full rounded-full bg-ink transition-all duration-700"
                          style={{ width: `${p?.bestPct ?? 0}%` }}
                        />
                      </div>
                      <div className="mt-2 flex items-center gap-3 text-[11px] text-warm-2">
                        <span className="tnum">{p?.attempts ?? 0} محاولة</span>
                        <span className="h-3 w-px bg-ink/15" />
                        <span className="tnum">أفضل نتيجة {p?.bestPct ?? 0}%</span>
                        {p?.pointAwarded ? (
                          <span className="rounded-full bg-sign-green/15 px-2 py-0.5 text-sign-green">
                            ✓ نقطة مكتسبة
                          </span>
                        ) : null}
                      </div>
                    </div>
                    <button
                      onClick={() => startLesson(l)}
                      className="shrink-0 rounded-full bg-ink px-5 py-2.5 text-[13px] font-bold text-paper transition hover:bg-sign-red"
                    >
                      {p ? "أعد الاختبار" : "ابدأ الاختبار"}
                    </button>
                  </div>
                </article>
              );
            })}
          </div>

          {/* الاختبار */}
          <div ref={quizRef} className="mt-12">
            {active && !result && (
              <div className="pop rounded-[24px] border-2 border-ink bg-paper p-6 shadow-[0_40px_90px_-40px_rgba(21,24,27,0.6)] sm:p-8">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <Sign kind={active.sign} size={40} />
                    <div>
                      <div className="tracked text-[9px] text-warm-2">اختبار {active.unit}</div>
                      <h3 className="font-display text-2xl text-ink">{active.title}</h3>
                    </div>
                  </div>
                  <button
                    onClick={() => setActive(null)}
                    className="rounded-full border border-ink/15 px-4 py-2 text-xs text-warm-2 transition hover:border-ink/40 hover:text-ink"
                  >
                    إغلاق
                  </button>
                </div>

                <div className="mt-6 space-y-7">
                  {active.questions.map((q, qi) => (
                    <QuestionBlock
                      key={qi}
                      q={q}
                      index={qi}
                      selected={answers[qi]}
                      onPick={(oi) => answer(qi, oi)}
                    />
                  ))}
                </div>

                <div className="mt-8 flex flex-wrap items-center justify-between gap-4 border-t border-ink/12 pt-6">
                  <div className="text-sm text-warm-2">
                    أجبت عن{" "}
                    <span className="tnum font-semibold text-ink">
                      {answers.filter((a) => a !== undefined).length}
                    </span>{" "}
                    من <span className="tnum font-semibold text-ink">{active.questions.length}</span> —
                    النجاح يتطلّب أعلى من {POINT_THRESHOLD}%.
                  </div>
                  <button
                    disabled={answers.filter((a) => a !== undefined).length < active.questions.length}
                    onClick={submitQuiz}
                    className="rounded-full bg-sign-red px-8 py-3.5 font-bold text-paper transition enabled:hover:scale-[1.03] enabled:active:scale-95 disabled:cursor-not-allowed disabled:opacity-35"
                  >
                    سلّم الإجابة
                  </button>
                </div>
              </div>
            )}

            {active && result && (
              <ResultCard
                lesson={active}
                result={result}
                onClose={() => {
                  setActive(null);
                  setResult(null);
                }}
                onRetry={() => {
                  setAnswers([]);
                  setResult(null);
                }}
              />
            )}
          </div>

          {/* المرآب */}
          <section id="garage" className="mt-16 scroll-mt-24">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <div className="tracked text-[10px] text-warm-2">
                  المكافآت · كل {POINTS_PER_GARAGE_SLOT} نقاط = خانة
                </div>
                <h2 className="mt-2 font-display text-5xl leading-tight text-ink">
                  مرآب السيارات الفخمة
                </h2>
              </div>
              <div className="rounded-2xl border border-ink/12 bg-paper-2/70 px-5 py-4">
                <div className="tracked text-[9px] text-warm-2">رصيدك الحالي</div>
                <div className="tnum text-3xl font-semibold leading-none text-ink">{points}</div>
              </div>
            </div>

            <div className="relative mt-8 h-[220px] overflow-hidden rounded-[22px] border border-ink/12">
              <img
                src="images/garage-car.jpg"
                alt="سيارة فخمة داخل المرآب تحت شعاع ضوء"
                className="absolute inset-0 h-full w-full object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-l from-transparent via-ink/25 to-ink/90" />
              <div className="absolute inset-y-0 right-0 flex max-w-md flex-col justify-center p-8">
                <div className="tracked text-[9px] text-road-yellow">المرآب · Luxury Garage</div>
                <p className="mt-3 font-display text-2xl leading-relaxed text-paper">
                  خلف كل باب مُغلق سيارة تنتظر سائقًا يستحقّها. اجمع نقاطك، افتح الخانة،
                  واسمع سؤالها: «هل أنت ستسوقني؟»
                </p>
              </div>
            </div>

            <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3">
              {Array.from({ length: GARAGE_SLOTS }).map((_, i) => {
                const tier = i + 1;
                const open = unlockedTiers.has(tier);
                const car = CARS[i];
                return (
                  <button
                    key={tier}
                    onClick={() => open && setGarageTier(tier)}
                    className={`group relative overflow-hidden rounded-[18px] border text-right transition ${
                      open
                        ? "border-ink/25 bg-ink text-paper hover:-translate-y-1 hover:shadow-[0_30px_60px_-28px_rgba(21,24,27,0.7)]"
                        : "cursor-default border-dashed border-ink/25 bg-paper-2/40 text-warm-2"
                    }`}
                  >
                    <div className="relative aspect-[4/3] overflow-hidden">
                      {open ? (
                        <>
                          <img
                            src="images/garage-car.jpg"
                            alt={`سيارة فخمة — ${car.name}`}
                            className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
                            loading="lazy"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/25 to-transparent" />
                        </>
                      ) : (
                        <div className="flex h-full w-full items-center justify-center bg-[repeating-linear-gradient(45deg,rgba(21,24,27,0.06)_0_10px,transparent_10px_20px)]">
                          <svg width="88" height="52" viewBox="0 0 88 52" aria-hidden="true">
                            <path
                              d="M8 42 C10 28 20 22 32 20 L44 10 H62 L74 22 C82 25 84 32 82 42 Z"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2.5"
                              strokeLinejoin="round"
                              opacity="0.5"
                            />
                            <circle cx="26" cy="42" r="7" fill="none" stroke="currentColor" strokeWidth="2.5" opacity="0.5" />
                            <circle cx="66" cy="42" r="7" fill="none" stroke="currentColor" strokeWidth="2.5" opacity="0.5" />
                          </svg>
                        </div>
                      )}
                    </div>
                    <div className={`p-4 ${open ? "" : "opacity-80"}`}>
                      <div className="tracked text-[9px] opacity-70">خانة {tier}</div>
                      <div className="mt-1 text-sm font-bold">
                        {open ? car.name : `تُفتح عند ${tier * POINTS_PER_GARAGE_SLOT} نقاط`}
                      </div>
                      <div className="mt-1 text-[11px] opacity-70">
                        {open ? `${car.tag} · ${car.power}` : `يتبقّى ${Math.max(0, tier * POINTS_PER_GARAGE_SLOT - points)} نقطة`}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>
        </div>

        {/* ── الريل الجانبي ── */}
        <aside className="lg:sticky lg:top-6 lg:h-fit">
          <div className="rounded-[22px] border border-ink/12 bg-ink p-6 text-paper">
            <div className="tracked text-[9px] text-road-yellow">مقياس النقاط</div>
            <div className="mt-4 flex items-end gap-3">
              <div className="tnum text-6xl font-semibold leading-none">{points}</div>
              <div className="pb-1 text-xs text-paper/60">نقطة</div>
            </div>

            <div className="mt-5 flex flex-col-reverse gap-1.5">
              {Array.from({ length: GARAGE_SLOTS }).map((_, i) => {
                const tier = i + 1;
                const open = unlockedTiers.has(tier);
                const threshold = tier * POINTS_PER_GARAGE_SLOT;
                const fill = Math.max(0, Math.min(1, (points - (threshold - 10)) / 10));
                return (
                  <div key={tier} className="flex items-center gap-2">
                    <div className="tnum w-6 text-[10px] text-paper/45">{tier}</div>
                    <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-white/10">
                      <div
                        className={`h-full rounded-full transition-all duration-700 ${
                          open ? "bg-road-yellow" : "bg-sign-red/70"
                        }`}
                        style={{ width: `${open ? 100 : fill * 100}%` }}
                      />
                    </div>
                    <div className="w-5 text-center text-[10px]">
                      {open ? "★" : <span className="text-paper/35">·</span>}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-5 rounded-xl bg-white/5 p-4 text-[11px] leading-6 text-paper/70">
              {pointsToNext > 0 ? (
                <>
                  تبقّى <span className="tnum text-road-yellow">{pointsToNext}</span> نقاط لفتح
                  خانة رقم <span className="tnum text-road-yellow">{nextTier}</span>.
                </>
              ) : (
                <>كل الخانات مفتوحة — أنت أسطورة المرآب.</>
              )}
              <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-road-yellow transition-all duration-700"
                  style={{ width: `${pctToNext}%` }}
                />
              </div>
            </div>

            <div className="mt-5 space-y-2 text-[11px] text-paper/60">
              <Row label="دروس مكتملة" value={`${lessonsDone}/${LESSONS.length}`} />
              <Row label="شرط النجاح" value={`> ${POINT_THRESHOLD}%`} />
              <Row label="الخانات المفتوحة" value={`${unlockedTiers.size}/${GARAGE_SLOTS}`} />
            </div>
          </div>

          <div className="mt-4 rounded-[18px] border border-ink/12 bg-paper-2/60 p-5">
            <h4 className="tracked text-[9px] text-warm-2">قواعد النقاط</h4>
            <ul className="mt-3 space-y-2.5 text-[12px] leading-6 text-warm-2">
              <li>• إتمام درس بنسبة أعلى من {POINT_THRESHOLD}% = نقطة واحدة.</li>
              <li>• مستويات اختبار القيادة في اللعبة تمنح نقاطًا إضافية.</li>
              <li>• كل {POINTS_PER_GARAGE_SLOT} نقاط = فتح خانة مرآب جديدة.</li>
              <li>• فتح الخانة يُطلق حوار السيارة الفخمة.</li>
              <li>• إكمال كل الدروس = المشهد الختامي الكبير.</li>
            </ul>
          </div>
        </aside>
      </div>

      {/* نافذة المرآب */}
      {garageTier !== null && (
        <GarageModal
          tier={garageTier}
          car={CARS[garageTier - 1]}
          allComplete={lessonsDone >= LESSONS.length}
          points={points}
          onClose={() => setGarageTier(null)}
        />
      )}

      {/* المشهد الختامي */}
      {finale && <Finale onClose={() => setFinale(false)} points={points} />}

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-6 left-1/2 z-[80] -translate-x-1/2">
          <div className="pop rounded-full border border-road-yellow/40 bg-ink px-6 py-3 text-sm text-paper shadow-[0_24px_50px_-18px_rgba(0,0,0,0.7)]">
            {toast}
          </div>
        </div>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between border-b border-white/8 pb-2">
      <span>{label}</span>
      <span className="tnum text-paper">{value}</span>
    </div>
  );
}

function QuestionBlock({
  q,
  index,
  selected,
  onPick,
}: {
  q: Question;
  index: number;
  selected?: number;
  onPick: (i: number) => void;
}) {
  return (
    <div className="scroll-mt-24">
      <div className="flex items-start gap-3">
        <span className="tnum mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-ink text-xs text-paper">
          {index + 1}
        </span>
        <h4 className="text-[16px] font-bold leading-8 text-ink">{q.q}</h4>
      </div>
      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        {q.options.map((opt, oi) => {
          const isSel = selected === oi;
          return (
            <button
              key={oi}
              onClick={() => onPick(oi)}
              className={`rounded-xl border px-4 py-3 text-right text-[13.5px] leading-6 transition ${
                isSel
                  ? "border-ink bg-ink text-paper"
                  : "border-ink/12 bg-paper hover:border-ink/35 hover:bg-paper-2/70"
              }`}
            >
              <span className="tnum ml-2 text-[11px] opacity-70">
                {["أ", "ب", "ج", "د", "هـ"][oi] ?? oi + 1}
              </span>
              {opt}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function ResultCard({
  lesson,
  result,
  onClose,
  onRetry,
}: {
  lesson: Lesson;
  result: {
    pct: number;
    correct: number;
    total: number;
    passed: boolean;
    pointAwarded: boolean;
    newUnlocks: { tier: number; carName: string }[];
  };
  onClose: () => void;
  onRetry: () => void;
}) {
  const line = result.passed
    ? "أداء متقن! هذه هي الطريقة التي يقود بها المحترفون."
    : "اقتربت كثيرًا — أعد المحاولة وستحصد النقطة.";
  return (
    <div className="pop overflow-hidden rounded-[24px] border-2 border-ink bg-ink text-paper">
      <div className="grid gap-0 sm:grid-cols-[1.1fr_1fr]">
        <div className="p-8">
          <div className="tracked text-[9px] text-road-yellow">نتيجة الاختبار</div>
          <div className="mt-3 flex items-end gap-3">
            <div
              className={`tnum text-7xl font-semibold leading-none ${
                result.passed ? "text-road-yellow" : "text-sign-red"
              }`}
            >
              {result.pct}%
            </div>
            <div className="pb-2 text-sm text-paper/60">
              {result.correct}/{result.total} إجابة صحيحة
            </div>
          </div>
          <p className="mt-4 font-display text-2xl leading-relaxed text-paper">{line}</p>
          <div className="mt-5 flex flex-wrap gap-3">
            <button
              onClick={onRetry}
              className="rounded-full bg-road-yellow px-6 py-3 text-sm font-bold text-ink transition hover:scale-105"
            >
              أعد المحاولة
            </button>
            <button
              onClick={onClose}
              className="rounded-full border border-white/20 px-6 py-3 text-sm font-bold transition hover:border-road-yellow"
            >
              الدرس التالي
            </button>
          </div>
        </div>
        <div className="relative min-h-[220px] bg-asphalt">
          <img
            src="images/dawn-road.jpg"
            alt="طريق عند الفجر"
            className="absolute inset-0 h-full w-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-gradient-to-l from-ink via-ink/35 to-transparent" />
          <div className="absolute bottom-0 right-0 p-6">
            <div className="rounded-xl border border-white/15 bg-black/55 px-4 py-3 text-[12px] leading-6 backdrop-blur-sm">
              {result.pointAwarded ? (
                <>
                  <strong className="text-road-yellow">+1 نقطة</strong> أُضيفت إلى مرآبك
                  {result.newUnlocks.length > 0 && (
                    <div className="mt-1 text-road-yellow">
                      فُتحت خانة {result.newUnlocks[0].tier}: {result.newUnlocks[0].carName}
                    </div>
                  )}
                </>
              ) : (
                <>
                  شرط النجاح: أعلى من {POINT_THRESHOLD}% بلا أخطاء — النتيجة الحالية {result.pct}%.
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function GarageModal({
  tier,
  car,
  allComplete,
  points,
  onClose,
}: {
  tier: number;
  car: { name: string; tag: string; power: string };
  allComplete: boolean;
  points: number;
  onClose: () => void;
}) {
  const [choice, setChoice] = useState<null | "yes" | "later">(null);
  const opening = allComplete
    ? "أراك أتممتَ كل الدروس... إذًا، هل أنت ستسوقني؟"
    : "هل أنت ستسوقني؟";
  const openingTyped = useTypewriter(opening, 34, true);

  const reply =
    choice === "yes"
      ? allComplete
        ? "نعم! أنت ستسوقني أيها السائق المحترف الذي ليس منك اثنان!"
        : "شجاعة جميلة... لكن الطريق لا يرحم من ينسى القواعد. أنهِ الدروس، وسأكون لك."
      : choice === "later"
        ? "لا بأس. كل سائق محترف بدأ من الصفر — سأنتظرك في الظل حتى تجهز."
        : "";
  const replyTyped = useTypewriter(reply, 26, choice !== null);

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center bg-black/85 p-4">
      <div className="pop w-full max-w-4xl overflow-hidden rounded-[26px] border border-white/12 bg-asphalt">
        <div className="grid md:grid-cols-2">
          <div className="relative min-h-[260px]">
            <img
              src="images/garage-car.jpg"
              alt={`سيارة فخمة — ${car.name}`}
              className="absolute inset-0 h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-l from-transparent via-transparent to-asphalt" />
            <div className="absolute top-4 right-4 rounded-full bg-black/60 px-4 py-2 text-[11px] text-road-yellow backdrop-blur-sm">
              خانة {tier} · {car.power}
            </div>
          </div>

          <div className="p-8">
            <div className="tracked text-[9px] text-road-yellow">{car.tag}</div>
            <h3 className="mt-2 font-display text-4xl leading-tight text-paper">{car.name}</h3>

            <div className="mt-6 min-h-[92px] rounded-2xl border border-white/12 bg-white/5 p-5">
              <div className="tracked text-[9px] text-paper/50">السيارة تخاطبك</div>
              <p className="mt-2 font-display text-2xl leading-relaxed text-road-yellow">
                {choice === null ? openingTyped : replyTyped}
                <span className="mr-1 inline-block h-5 w-[3px] animate-pulse bg-road-yellow align-middle" />
              </p>
            </div>

            {choice === null ? (
              <div className="mt-5 flex flex-wrap gap-3">
                <button
                  onClick={() => setChoice("yes")}
                  className="rounded-full bg-road-yellow px-6 py-3 text-sm font-bold text-ink transition hover:scale-105"
                >
                  نعم، سأقودك بإتقان
                </button>
                <button
                  onClick={() => setChoice("later")}
                  className="rounded-full border border-white/20 px-6 py-3 text-sm font-bold text-paper transition hover:border-road-yellow"
                >
                  لستّ مستعدًا بعد
                </button>
              </div>
            ) : (
              <div className="mt-5 flex flex-wrap items-center gap-3">
                <button
                  onClick={onClose}
                  className="rounded-full bg-road-yellow px-6 py-3 text-sm font-bold text-ink transition hover:scale-105"
                >
                  عودة إلى المرآب
                </button>
                <span className="text-[11px] text-paper/50">
                  رصيدك: <span className="tnum text-paper">{points}</span> نقطة
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      <button
        onClick={onClose}
        aria-label="إغلاق"
        className="absolute top-5 left-5 rounded-full border border-white/20 bg-black/50 px-4 py-2 text-xs text-paper transition hover:border-road-yellow"
      >
        إغلاق
      </button>
    </div>
  );
}

function Finale({ onClose, points }: { onClose: () => void; points: number }) {
  const line = "نعم! أنت ستسوقني أيها السائق المحترف الذي ليس منك اثنان!";
  const typed = useTypewriter(line, 45, true);
  return (
    <div className="fixed inset-0 z-[95] overflow-hidden bg-asphalt">
      <img
        src="images/dawn-road.jpg"
        alt="طريق عند الفجر"
        className="absolute inset-0 h-full w-full object-cover opacity-75"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-asphalt via-asphalt/55 to-asphalt/25" />
      <div className="absolute inset-0">
        {Array.from({ length: 26 }).map((_, i) => (
          <span
            key={i}
            className="absolute h-1.5 w-1.5 rounded-full bg-road-yellow/80"
            style={{
              left: `${(i * 37) % 100}%`,
              top: `${(i * 53) % 100}%`,
              animation: `rise ${1.2 + (i % 5) * 0.5}s ease-in-out ${(i % 7) * 0.25}s infinite alternate`,
            }}
          />
        ))}
      </div>

      <div className="relative flex h-full flex-col items-center justify-center px-6 text-center">
        <div className="tracked text-[10px] text-road-yellow">المشهد الختامي · اكتمل المنهج</div>
        <h2 className="mt-6 max-w-4xl font-display text-5xl leading-[1.25] text-paper sm:text-7xl">
          {typed}
          <span className="mr-1 inline-block h-12 w-[4px] animate-pulse bg-road-yellow align-middle" />
        </h2>
        <p className="mt-7 max-w-xl text-[15px] leading-8 text-paper/75">
          أنهيتَ {LESSONS.length} دروس واجتزتَ كل اختبار بنسبة أعلى من {POINT_THRESHOLD}%.
          رصيدك النهائي في المرآب: <span className="tnum text-road-yellow">{points}</span> نقطة.
        </p>
        <div className="mt-9 flex flex-wrap justify-center gap-3">
          <button
            onClick={onClose}
            className="rounded-full bg-road-yellow px-8 py-4 font-bold text-ink shadow-[0_20px_50px_-16px_rgba(242,183,5,0.75)] transition hover:scale-105 active:scale-95"
          >
            اقود الآن
          </button>
          <a
            href="#game"
            onClick={onClose}
            className="rounded-full border border-white/25 px-8 py-4 font-bold text-paper transition hover:border-road-yellow"
          >
            إلى لعبة الشارع
          </a>
        </div>
      </div>
    </div>
  );
}
