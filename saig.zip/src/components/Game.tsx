"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { describeEarned, emitPoints, evaluateRun } from "@/lib/achievements";

type Phase = "ready" | "playing" | "paused" | "over";

type Obstacle = {
  kind: "cone" | "barrier" | "car";
  x: number;
  y: number;
  w: number;
  h: number;
  color: string;
  speed: number;
};

type Token = {
  x: number;
  y: number;
  r: number;
  kind: "warn" | "yield" | "no" | "must";
  pulse: number;
};

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
  grav: number;
  shape: "dot" | "spark" | "ring";
};

type GameState = {
  w: number;
  h: number;
  u: number;
  roadW: number;
  roadX: number;
  scroll: number;
  car: { x: number; y: number; vx: number; tilt: number };
  speed: number;
  elapsed: number;
  spawnTimer: number;
  tokenTimer: number;
  obstacles: Obstacle[];
  tokens: Token[];
  particles: Particle[];
  shake: number;
  flash: number;
  hearts: number;
  invuln: number;
  score: number;
  distance: number;
  collected: number;
  combo: number;
  comboTimer: number;
  lastTime: number;
};

type LocalScore = { name: string; score: number; date: string };

const LS_KEY = "garage_racer_scores_v1";

function loadLocalScores(): LocalScore[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(LS_KEY);
    return raw ? (JSON.parse(raw) as LocalScore[]) : [];
  } catch {
    return [];
  }
}

function saveLocalScore(entry: LocalScore): LocalScore[] {
  const list = [...loadLocalScores(), entry].sort((a, b) => b.score - a.score).slice(0, 6);
  try {
    window.localStorage.setItem(LS_KEY, JSON.stringify(list));
  } catch {
    /* تجاهل */
  }
  return list;
}

/* ── صوت بسيط جدًا (WebAudio) ── */
function useAudio() {
  const ctxRef = useRef<AudioContext | null>(null);
  const [muted, setMuted] = useState(false);
  const mutedRef = useRef(false);
  mutedRef.current = muted;

  const ensure = useCallback(() => {
    if (!ctxRef.current) {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (AC) ctxRef.current = new AC();
    }
    if (ctxRef.current?.state === "suspended") void ctxRef.current.resume();
    return ctxRef.current;
  }, []);

  const play = useCallback(
    (freq: number, dur: number, type: OscillatorType = "sine", gain = 0.05, slide = 0) => {
      if (mutedRef.current) return;
      const ac = ensure();
      if (!ac) return;
      const o = ac.createOscillator();
      const g = ac.createGain();
      o.type = type;
      o.frequency.setValueAtTime(freq, ac.currentTime);
      if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), ac.currentTime + dur);
      g.gain.setValueAtTime(gain, ac.currentTime);
      g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + dur);
      o.connect(g).connect(ac.destination);
      o.start();
      o.stop(ac.currentTime + dur);
    },
    [ensure],
  );

  return { play, ensure, muted, setMuted };
}

export default function Game() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const [phase, setPhase] = useState<Phase>("ready");
  const phaseRef = useRef<Phase>("ready");
  const [hud, setHud] = useState({
    score: 0,
    speed: 0,
    combo: 1,
    hearts: 3,
    distance: 0,
    collected: 0,
    best: 0,
  });
  const [localScores, setLocalScores] = useState<LocalScore[]>([]);
  const [serverScores, setServerScores] = useState<
    { playerName: string; score: number; distance: number }[]
  >([]);
  const [lastRun, setLastRun] = useState<{ score: number; distance: number; collected: number } | null>(
    null,
  );
  const [roundRewards, setRoundRewards] = useState<null | {
    awarded: { key: string; label: string; threshold: string }[];
    points: number;
    newUnlocks: { tier: number; carName: string }[];
  }>(null);
  const submittedRef = useRef(false);
  const { play, ensure, muted, setMuted } = useAudio();

  const stateRef = useRef<GameState>({
    w: 800,
    h: 520,
    u: 1,
    roadW: 460,
    roadX: 170,
    scroll: 0,
    car: { x: 400, y: 380, vx: 0, tilt: 0 },
    speed: 220,
    elapsed: 0,
    spawnTimer: 1,
    tokenTimer: 1.2,
    obstacles: [],
    tokens: [],
    particles: [],
    shake: 0,
    flash: 0,
    hearts: 3,
    invuln: 0,
    score: 0,
    distance: 0,
    collected: 0,
    combo: 1,
    comboTimer: 0,
    lastTime: 0,
  });

  const inputRef = useRef({ left: false, right: false, pointerX: null as number | null });

  useEffect(() => {
    setLocalScores(loadLocalScores());
    fetch("/api/scores")
      .then((r) => r.json())
      .then((d) => {
        if (d?.scores) setServerScores(d.scores);
      })
      .catch(() => undefined);
  }, []);

  const startGame = useCallback(() => {
    const s = stateRef.current;
    s.car.x = s.w / 2;
    s.car.vx = 0;
    s.obstacles = [];
    s.tokens = [];
    s.particles = [];
    s.speed = 300;
    s.elapsed = 0;
    s.spawnTimer = 1.1;
    s.tokenTimer = 0.9;
    s.shake = 0;
    s.flash = 0;
    s.hearts = 3;
    s.invuln = 0;
    s.score = 0;
    s.distance = 0;
    s.collected = 0;
    s.combo = 1;
    s.comboTimer = 0;
    submittedRef.current = false;
    setLastRun(null);
    setRoundRewards(null);
    phaseRef.current = "playing";
    setPhase("playing");
    ensure();
    play(520, 0.09, "square", 0.05, 260);
  }, [ensure, play]);

  const pauseGame = useCallback(() => {
    if (phaseRef.current === "playing") {
      phaseRef.current = "paused";
      setPhase("paused");
    } else if (phaseRef.current === "paused") {
      phaseRef.current = "playing";
      setPhase("playing");
    }
  }, []);

  const endGame = useCallback(() => {
    const s = stateRef.current;
    phaseRef.current = "over";
    setPhase("over");
    const run = {
      score: Math.round(s.score),
      distance: Math.round(s.distance),
      collected: s.collected,
      tokens: s.collected,
      seconds: Math.round(s.elapsed),
    };
    setLastRun(run);
    const best = Math.max(loadLocalScores()[0]?.score ?? 0, run.score);
    setHud((h) => ({ ...h, best: Math.round(best) }));
    setLocalScores(saveLocalScore({ name: "أنت", score: run.score, date: new Date().toISOString() }));
    if (!submittedRef.current) {
      submittedRef.current = true;
      const earned = evaluateRun(run);
      fetch("/api/game-result", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(run),
      })
        .then((r) => r.json())
        .then((d) => {
          if (d && !d.error) {
            setRoundRewards({
              awarded: describeEarned(d.awarded ?? []),
              points: d.points,
              newUnlocks: d.newUnlocks ?? [],
            });
            emitPoints({
              points: d.points,
              newUnlocks: d.newUnlocks ?? [],
              awarded: d.awarded ?? [],
            });
          }
        })
        .catch(() => undefined);

      fetch("/api/scores", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          playerName: "سائق الشارع",
          score: run.score,
          distance: run.distance,
          tokens: run.collected,
        }),
      })
        .then((r) => r.json())
        .then((d) => {
          if (d?.scores) setServerScores(d.scores);
        })
        .catch(() => undefined);
    }
  }, []);

  /* ── المحرّك ── */
  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) return;

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(320, rect.width);
      const h = Math.max(360, rect.height);
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      const s = stateRef.current;
      s.w = w;
      s.h = h;
      s.u = Math.max(0.62, Math.min(1.15, w / 720));
      s.roadW = Math.min(w * 0.78, 520 * s.u);
      s.roadX = (w - s.roadW) / 2;
      s.car.x = Math.min(Math.max(s.car.x, s.roadX + 40), s.roadX + s.roadW - 40);
      s.car.y = h - 150 * s.u;
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    const addParticles = (
      x: number,
      y: number,
      count: number,
      color: string,
      shape: Particle["shape"],
      power = 1,
    ) => {
      const s = stateRef.current;
      for (let i = 0; i < count; i++) {
        const a = Math.random() * Math.PI * 2;
        const sp = (60 + Math.random() * 260) * power;
        s.particles.push({
          x,
          y,
          vx: Math.cos(a) * sp,
          vy: Math.sin(a) * sp - 40,
          life: 0,
          max: 0.35 + Math.random() * 0.55,
          size: (2 + Math.random() * 5) * s.u,
          color,
          grav: shape === "spark" ? 380 : 120,
          shape,
        });
      }
      if (s.particles.length > 420) s.particles.splice(0, s.particles.length - 420);
    };

    const spawnObstacle = () => {
      const s = stateRef.current;
      const lanes = 3;
      const laneW = s.roadW / lanes;
      const lane = Math.floor(Math.random() * lanes);
      const roll = Math.random();
      const kind: Obstacle["kind"] = roll < 0.42 ? "cone" : roll < 0.72 ? "barrier" : "car";
      const w = (kind === "cone" ? 38 : kind === "barrier" ? 108 : 62) * s.u;
      const h = (kind === "cone" ? 42 : kind === "barrier" ? 34 : 116) * s.u;
      const x = s.roadX + laneW * lane + laneW / 2 - w / 2 + (Math.random() - 0.5) * laneW * 0.22;
      s.obstacles.push({
        kind,
        x,
        y: -h - 20,
        w,
        h,
        color:
          kind === "car"
            ? ["#2C3E52", "#7A1F2B", "#2F5D4A", "#4A4458"][Math.floor(Math.random() * 4)]
            : "#E2761B",
        speed: kind === "car" ? 0.42 + Math.random() * 0.22 : 0,
      });
    };

    const spawnToken = () => {
      const s = stateRef.current;
      const lanes = 3;
      const laneW = s.roadW / lanes;
      const lane = Math.floor(Math.random() * lanes);
      const kinds: Token["kind"][] = ["warn", "yield", "no", "must"];
      s.tokens.push({
        x: s.roadX + laneW * lane + laneW / 2,
        y: -40,
        r: 20 * s.u,
        kind: kinds[Math.floor(Math.random() * kinds.length)],
        pulse: Math.random() * Math.PI * 2,
      });
    };

    const carW = () => 58 * stateRef.current.u;
    const carH = () => 116 * stateRef.current.u;

    const drawCar = (x: number, y: number, w: number, h: number, tilt: number, color: string, hero: boolean) => {
      const r = 12 * stateRef.current.u;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(tilt);
      // ظل
      ctx.fillStyle = "rgba(0,0,0,0.45)";
      ctx.beginPath();
      ctx.ellipse(0, h * 0.06, w * 0.62, h * 0.52, 0, 0, Math.PI * 2);
      ctx.fill();
      // أضواء أمامية
      if (hero) {
        const g = ctx.createLinearGradient(0, -h / 2, 0, -h / 2 - 190);
        g.addColorStop(0, "rgba(255,226,160,0.30)");
        g.addColorStop(1, "rgba(255,226,160,0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.moveTo(-w * 0.34, -h / 2);
        ctx.lineTo(w * 0.34, -h / 2);
        ctx.lineTo(w * 1.25, -h / 2 - 200);
        ctx.lineTo(-w * 1.25, -h / 2 - 200);
        ctx.closePath();
        ctx.fill();
      }
      // جسم
      const body = ctx.createLinearGradient(-w / 2, 0, w / 2, 0);
      body.addColorStop(0, color);
      body.addColorStop(0.45, "#F2E7D5");
      body.addColorStop(0.55, "#F2E7D5");
      body.addColorStop(1, color);
      ctx.fillStyle = body;
      ctx.beginPath();
      ctx.moveTo(-w / 2 + r, -h / 2);
      ctx.lineTo(w / 2 - r, -h / 2);
      ctx.quadraticCurveTo(w / 2, -h / 2, w / 2, -h / 2 + r);
      ctx.lineTo(w / 2, h / 2 - r);
      ctx.quadraticCurveTo(w / 2, h / 2, w / 2 - r, h / 2);
      ctx.lineTo(-w / 2 + r, h / 2);
      ctx.quadraticCurveTo(-w / 2, h / 2, -w / 2, h / 2 - r);
      ctx.lineTo(-w / 2, -h / 2 + r);
      ctx.quadraticCurveTo(-w / 2, -h / 2, -w / 2 + r, -h / 2);
      ctx.closePath();
      ctx.fill();
      // زجاج
      ctx.fillStyle = "#1B2430";
      ctx.beginPath();
      ctx.moveTo(-w * 0.32, -h * 0.22);
      ctx.lineTo(w * 0.32, -h * 0.22);
      ctx.lineTo(w * 0.26, h * 0.02);
      ctx.lineTo(-w * 0.26, h * 0.02);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "#243040";
      ctx.beginPath();
      ctx.moveTo(-w * 0.28, h * 0.24);
      ctx.lineTo(w * 0.28, h * 0.24);
      ctx.lineTo(w * 0.22, h * 0.42);
      ctx.lineTo(-w * 0.22, h * 0.42);
      ctx.closePath();
      ctx.fill();
      // أضواء خلفية
      ctx.fillStyle = "#FF3B3B";
      ctx.fillRect(-w * 0.4, h / 2 - 10 * stateRef.current.u, w * 0.22, 8 * stateRef.current.u);
      ctx.fillRect(w * 0.18, h / 2 - 10 * stateRef.current.u, w * 0.22, 8 * stateRef.current.u);
      // خط سباق
      ctx.fillStyle = "#C8102E";
      ctx.fillRect(-w * 0.05, -h * 0.5, w * 0.1, h * 1.0);
      ctx.restore();
    };

    const drawToken = (t: Token) => {
      const colors: Record<Token["kind"], string> = {
        warn: "#F2B705",
        yield: "#C8102E",
        no: "#C8102E",
        must: "#3D7BD9",
      };
      const c = colors[t.kind];
      const glow = ctx.createRadialGradient(t.x, t.y, 2, t.x, t.y, t.r * 2.6);
      glow.addColorStop(0, `${c}88`);
      glow.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(t.x, t.y, t.r * 2.6, 0, Math.PI * 2);
      ctx.fill();

      ctx.save();
      ctx.translate(t.x, t.y);
      const scale = 1 + Math.sin(t.pulse) * 0.07;
      ctx.scale(scale, scale);
      ctx.fillStyle = "#F7F3EA";
      ctx.strokeStyle = c;
      ctx.lineWidth = 5;
      if (t.kind === "warn" || t.kind === "yield") {
        ctx.beginPath();
        ctx.moveTo(0, -t.r);
        ctx.lineTo(t.r, t.r * 0.8);
        ctx.lineTo(-t.r, t.r * 0.8);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      } else if (t.kind === "no") {
        ctx.beginPath();
        ctx.arc(0, 0, t.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      } else {
        ctx.beginPath();
        ctx.arc(0, 0, t.r, 0, Math.PI * 2);
        ctx.fillStyle = c;
        ctx.fill();
        ctx.strokeStyle = "#F7F3EA";
        ctx.stroke();
      }
      ctx.fillStyle = t.kind === "must" ? "#fff" : "#15181B";
      ctx.beginPath();
      ctx.arc(0, 0, t.r * 0.22, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    };

    let raf = 0;
    let hudTick = 0;
    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      const s = stateRef.current;
      const dtRaw = s.lastTime ? (now - s.lastTime) / 1000 : 0.016;
      const dt = Math.min(0.033, dtRaw);
      s.lastTime = now;

      const playing = phaseRef.current === "playing";
      const idle = phaseRef.current === "ready" || phaseRef.current === "over";

      if (playing) {
        s.elapsed += dt;
        s.speed = Math.min(880 * s.u, 300 * s.u + s.elapsed * 13 * s.u);
        s.score += dt * s.speed * 0.055;
        s.distance += (dt * s.speed) / 12;
        s.spawnTimer -= dt;
        s.tokenTimer -= dt;
        s.invuln = Math.max(0, s.invuln - dt);
        s.flash = Math.max(0, s.flash - dt * 2.2);
        s.shake = Math.max(0, s.shake - dt * 46);
        if (s.comboTimer > 0) {
          s.comboTimer -= dt;
          if (s.comboTimer <= 0) s.combo = 1;
        }

        if (s.spawnTimer <= 0) {
          spawnObstacle();
          s.spawnTimer = Math.max(0.34, 1.15 - s.elapsed * 0.012) * (320 / (s.speed / s.u));
        }
        if (s.tokenTimer <= 0) {
          spawnToken();
          s.tokenTimer = 1.05 + Math.random() * 1.1;
        }

        // تحكّم
        const input = inputRef.current;
        const maxV = 620 * s.u;
        let target = 0;
        if (input.left) target -= maxV;
        if (input.right) target += maxV;
        if (input.pointerX !== null) {
          const diff = input.pointerX - s.car.x;
          target = Math.max(-maxV, Math.min(maxV, diff * 6));
        }
        s.car.vx += (target - s.car.vx) * Math.min(1, dt * 11);
        s.car.x += s.car.vx * dt;
        s.car.tilt += ((s.car.vx / maxV) * 0.22 - s.car.tilt) * Math.min(1, dt * 9);
        const pad = carW() * 0.62;
        const minX = s.roadX + pad;
        const maxX = s.roadX + s.roadW - pad;
        if (s.car.x < minX) {
          s.car.x = minX;
          s.car.vx = 0;
        }
        if (s.car.x > maxX) {
          s.car.x = maxX;
          s.car.vx = 0;
        }
      } else if (idle) {
        s.speed = 200 * s.u;
        s.car.vx *= 0.9;
        s.shake = Math.max(0, s.shake - dt * 46);
        s.flash = Math.max(0, s.flash - dt * 2.2);
      }

      // تمرير العالم
      s.scroll += s.speed * dt;

      // تحريك الكائنات
      const moveY = (y: number, extra = 0) => y + (s.speed * (1 - extra)) * dt;
      for (const o of s.obstacles) o.y = moveY(o.y, o.speed);
      for (const t of s.tokens) {
        t.y = moveY(t.y);
        t.pulse += dt * 3.4;
      }
      for (const p of s.particles) {
        p.life += dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt + s.speed * dt * 0.35;
        p.vy += p.grav * dt;
        p.vx *= 0.985;
      }
      s.particles = s.particles.filter((p) => p.life < p.max);
      s.obstacles = s.obstacles.filter((o) => o.y < s.h + 180);
      s.tokens = s.tokens.filter((t) => t.y < s.h + 80);

      // تصادم
      if (playing) {
        const cw = carW() * 0.78;
        const ch = carH() * 0.82;
        for (const o of s.obstacles) {
          const ow = o.w * 0.82;
          const oh = o.h * 0.84;
          if (
            Math.abs(s.car.x - (o.x + o.w / 2)) < (cw + ow) / 2 &&
            Math.abs(s.car.y - (o.y + o.h / 2)) < (ch + oh) / 2
          ) {
            if (s.invuln <= 0) {
              s.invuln = 1.5;
              s.hearts -= 1;
              s.shake = reduceMotion ? 4 : 26;
              s.flash = 1;
              s.combo = 1;
              s.comboTimer = 0;
              addParticles(s.car.x, s.car.y - carH() * 0.3, 26, "#F2B705", "spark", 1.2);
              addParticles(s.car.x, s.car.y - carH() * 0.3, 14, "#C8102E", "dot", 1);
              play(140, 0.28, "sawtooth", 0.09, -70);
              o.y = s.h + 400;
              if (s.hearts <= 0) {
                addParticles(s.car.x, s.car.y, 60, "#F2B705", "spark", 1.6);
                endGame();
              }
            }
          }
        }
        for (const t of s.tokens) {
          const d = Math.hypot(s.car.x - t.x, s.car.y - t.y);
          if (d < t.r + carW() * 0.55) {
            s.collected += 1;
            s.combo = Math.min(12, s.combo + 1);
            s.comboTimer = 5;
            s.score += 40 * Math.min(5, s.combo);
            addParticles(t.x, t.y, 16, "#F2B705", "spark", 0.9);
            addParticles(t.x, t.y, 8, "#F7F3EA", "ring", 0.5);
            play(620 + s.combo * 45, 0.12, "triangle", 0.06, 180);
            t.y = s.h + 900;
          }
        }
      }

      /* ── الرسم ── */
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const w = s.w;
      const h = s.h;

      // الإسفلت
      const asphalt = ctx.createLinearGradient(0, 0, 0, h);
      asphalt.addColorStop(0, "#0E1116");
      asphalt.addColorStop(0.5, "#171B21");
      asphalt.addColorStop(1, "#0B0E12");
      ctx.fillStyle = asphalt;
      ctx.fillRect(0, 0, w, h);

      ctx.save();
      if (s.shake > 0) {
        ctx.translate((Math.random() - 0.5) * s.shake, (Math.random() - 0.5) * s.shake);
      }

      // كتف الطريق
      ctx.fillStyle = "#2A2118";
      ctx.fillRect(0, 0, s.roadX, h);
      ctx.fillRect(s.roadX + s.roadW, 0, w - s.roadX - s.roadW, h);

      // سطح الطريق
      const road = ctx.createLinearGradient(s.roadX, 0, s.roadX + s.roadW, 0);
      road.addColorStop(0, "#1A1F26");
      road.addColorStop(0.5, "#22282F");
      road.addColorStop(1, "#1A1F26");
      ctx.fillStyle = road;
      ctx.fillRect(s.roadX, 0, s.roadW, h);

      // خطوط الحافة
      ctx.fillStyle = "#F2B705";
      ctx.fillRect(s.roadX + 4 * s.u, 0, 5 * s.u, h);
      ctx.fillRect(s.roadX + s.roadW - 9 * s.u, 0, 5 * s.u, h);

      // خطوط المسارات المتقطعة
      const dashH = 74 * s.u;
      const gap = 62 * s.u;
      const cycle = dashH + gap;
      const offset = s.scroll % cycle;
      ctx.fillStyle = "rgba(226,231,238,0.62)";
      for (const frac of [1 / 3, 2 / 3]) {
        const x = s.roadX + s.roadW * frac - 3 * s.u;
        for (let y = -cycle + offset; y < h + cycle; y += cycle) {
          ctx.fillRect(x, y, 6 * s.u, dashH);
        }
      }

      // أعمدة الطريق
      const postCycle = 190 * s.u;
      const postOff = s.scroll % postCycle;
      for (let y = -postCycle + postOff; y < h + postCycle; y += postCycle) {
        ctx.fillStyle = "#3B3226";
        ctx.fillRect(s.roadX - 26 * s.u, y, 12 * s.u, 74 * s.u);
        ctx.fillRect(s.roadX + s.roadW + 14 * s.u, y, 12 * s.u, 74 * s.u);
        ctx.fillStyle = "#F2B705";
        ctx.fillRect(s.roadX - 26 * s.u, y + 6 * s.u, 12 * s.u, 12 * s.u);
        ctx.fillRect(s.roadX + s.roadW + 14 * s.u, y + 6 * s.u, 12 * s.u, 12 * s.u);
      }

      for (const t of s.tokens) drawToken(t);
      for (const o of s.obstacles) {
        if (o.kind === "cone") {
          ctx.fillStyle = "rgba(0,0,0,0.4)";
          ctx.beginPath();
          ctx.ellipse(o.x + o.w / 2, o.y + o.h, o.w * 0.62, o.h * 0.16, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "#E2761B";
          ctx.beginPath();
          ctx.moveTo(o.x + o.w / 2, o.y);
          ctx.lineTo(o.x + o.w, o.y + o.h);
          ctx.lineTo(o.x, o.y + o.h);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = "#F7F3EA";
          ctx.fillRect(o.x + o.w * 0.22, o.y + o.h * 0.46, o.w * 0.56, o.h * 0.16);
        } else if (o.kind === "barrier") {
          ctx.fillStyle = "#2A2F36";
          ctx.fillRect(o.x, o.y + o.h * 0.55, o.w, o.h * 0.45);
          for (let i = 0; i < 5; i++) {
            ctx.fillStyle = i % 2 ? "#F2E7D5" : "#C8102E";
            ctx.fillRect(o.x + (i * o.w) / 5, o.y, o.w / 5, o.h * 0.62);
          }
        } else {
          drawCar(o.x + o.w / 2, o.y + o.h / 2, o.w, o.h, 0, o.color, false);
        }
      }

      // السيارة
      const blink = s.invuln > 0 && Math.floor(s.invuln * 12) % 2 === 0;
      if (!blink) {
        drawCar(s.car.x, s.car.y, carW(), carH(), s.car.tilt, "#C8102E", true);
      }

      // الجسيمات
      for (const p of s.particles) {
        const k = 1 - p.life / p.max;
        ctx.globalAlpha = Math.max(0, k);
        if (p.shape === "ring") {
          ctx.strokeStyle = p.color;
          ctx.lineWidth = 3 * s.u;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * (2.4 - k) * 2.2, 0, Math.PI * 2);
          ctx.stroke();
        } else if (p.shape === "spark") {
          ctx.fillStyle = p.color;
          ctx.fillRect(p.x, p.y, p.size * 1.9, p.size * 0.6);
        } else {
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * k, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.globalAlpha = 1;
      }

      ctx.restore();

      // تعتيم الأطراف
      const vig = ctx.createRadialGradient(w / 2, h * 0.52, h * 0.18, w / 2, h * 0.52, h * 0.92);
      vig.addColorStop(0, "rgba(0,0,0,0)");
      vig.addColorStop(1, "rgba(0,0,0,0.62)");
      ctx.fillStyle = vig;
      ctx.fillRect(0, 0, w, h);

      if (s.flash > 0) {
        ctx.fillStyle = `rgba(200,16,46,${s.flash * 0.42})`;
        ctx.fillRect(0, 0, w, h);
      }

      // تحديث HUD كل ~6 إطارات
      if (now - hudTick > 90) {
        hudTick = now;
        setHud((prev) => ({
          ...prev,
          score: Math.round(s.score),
          speed: Math.round((s.speed / s.u) * 0.42),
          combo: Math.min(5, s.combo),
          hearts: s.hearts,
          distance: Math.round(s.distance),
          collected: s.collected,
        }));
      }
    };
    raf = requestAnimationFrame(frame);

    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === "arrowleft" || k === "a") {
        inputRef.current.left = true;
        inputRef.current.pointerX = null;
        e.preventDefault();
      }
      if (k === "arrowright" || k === "d") {
        inputRef.current.right = true;
        inputRef.current.pointerX = null;
        e.preventDefault();
      }
      if (k === " " || k === "enter") {
        e.preventDefault();
        if (phaseRef.current !== "playing") startGame();
      }
      if (k === "p" || k === "escape") {
        e.preventDefault();
        pauseGame();
      }
      if (k === "r") {
        e.preventDefault();
        startGame();
      }
      if (k === "m") setMuted((m) => !m);
    };
    const onKeyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === "arrowleft" || k === "a") inputRef.current.left = false;
      if (k === "arrowright" || k === "d") inputRef.current.right = false;
    };

    const pointerPos = (e: PointerEvent) => {
      const rect = canvas.getBoundingClientRect();
      return ((e.clientX - rect.left) / rect.width) * stateRef.current.w;
    };
    const onDown = (e: PointerEvent) => {
      ensure();
      if (phaseRef.current !== "playing") return;
      canvas.setPointerCapture(e.pointerId);
      inputRef.current.pointerX = pointerPos(e);
    };
    const onMove = (e: PointerEvent) => {
      if (inputRef.current.pointerX === null) return;
      inputRef.current.pointerX = pointerPos(e);
    };
    const onUp = () => {
      inputRef.current.pointerX = null;
    };

    window.addEventListener("keydown", onKey);
    window.addEventListener("keyup", onKeyUp);
    canvas.addEventListener("pointerdown", onDown);
    canvas.addEventListener("pointermove", onMove);
    canvas.addEventListener("pointerup", onUp);
    canvas.addEventListener("pointercancel", onUp);
    canvas.addEventListener("pointerleave", onUp);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("keyup", onKeyUp);
      canvas.removeEventListener("pointerdown", onDown);
      canvas.removeEventListener("pointermove", onMove);
      canvas.removeEventListener("pointerup", onUp);
      canvas.removeEventListener("pointercancel", onUp);
      canvas.removeEventListener("pointerleave", onUp);
    };
  }, [endGame, ensure, pauseGame, play, setMuted, startGame]);

  const hold = (dir: "left" | "right") => ({
    onPointerDown: (e: React.PointerEvent) => {
      e.preventDefault();
      inputRef.current[dir] = true;
      inputRef.current.pointerX = null;
    },
    onPointerUp: () => {
      inputRef.current[dir] = false;
    },
    onPointerLeave: () => {
      inputRef.current[dir] = false;
    },
    onPointerCancel: () => {
      inputRef.current[dir] = false;
    },
  });

  return (
    <div className="relative">
      <div
        ref={wrapRef}
        className="relative h-[62vh] min-h-[420px] w-full overflow-hidden rounded-[26px] border-[6px] border-ink/90 bg-asphalt shadow-[0_40px_90px_-30px_rgba(0,0,0,0.65)]"
      >
        <canvas ref={canvasRef} className="block h-full w-full touch-none select-none" />

        {/* HUD */}
        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-3 p-3 sm:p-5">
          <div className="rounded-2xl border border-white/10 bg-black/55 px-4 py-3 backdrop-blur-sm">
            <div className="tracked text-[9px] text-road-yellow/80">النقاط</div>
            <div className="tnum text-3xl font-semibold leading-none text-paper">
              {hud.score.toLocaleString("en-US")}
            </div>
            <div className="mt-2 flex items-center gap-3 text-[11px] text-paper/70">
              <span className="tnum">{hud.distance} م</span>
              <span className="h-3 w-px bg-white/20" />
              <span className="tnum">{hud.collected} إشارة</span>
            </div>
          </div>

          <div className="flex flex-col items-center gap-2">
            <div className="rounded-full border border-white/10 bg-black/55 px-4 py-2 text-center backdrop-blur-sm">
              <div className="tnum text-2xl font-semibold leading-none text-road-yellow">
                {hud.speed}
              </div>
              <div className="tracked text-[9px] text-paper/60">كم/س</div>
            </div>
            <div className="rounded-full border border-road-yellow/30 bg-road-yellow/15 px-3 py-1 text-center">
              <div className="tnum text-sm font-semibold text-road-yellow">×{hud.combo}</div>
            </div>
          </div>

          <div className="flex flex-col items-end gap-2">
            <div className="flex gap-1.5">
              {[0, 1, 2].map((i) => (
                <span
                  key={i}
                  className={`h-3.5 w-8 rounded-full ${
                    i < hud.hearts ? "bg-sign-red" : "bg-white/15"
                  }`}
                />
              ))}
            </div>
            <button
              onClick={() => setMuted((m) => !m)}
              className="pointer-events-auto rounded-full border border-white/10 bg-black/55 px-3 py-1.5 text-[11px] text-paper/80 transition hover:border-road-yellow/50 hover:text-road-yellow"
            >
              {muted ? "الصوت: مغلق" : "الصوت: مفتوح"}
            </button>
          </div>
        </div>

        {/* لوحات */}
        {phase !== "playing" && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/72 px-5 backdrop-blur-[3px]">
            {phase === "ready" && (
              <div className="pop w-full max-w-md text-center">
                <div className="tracked mb-3 text-[10px] text-road-yellow">
                  لعبة الشارع · مستوى السائق المحترف
                </div>
                <h3 className="font-display text-5xl leading-tight text-paper">
                  أمسك المقود
                </h3>
                <p className="mx-auto mt-3 max-w-sm text-sm leading-7 text-paper/75">
                  تفادَ الحواجز والمخاريط، اجمع لافتات المرور لرفع المضاعِف، وحافظ على
                  مراتب الأمان الثلاث.
                </p>
                <button
                  onClick={startGame}
                  className="mt-6 rounded-full bg-road-yellow px-9 py-4 text-base font-bold text-ink shadow-[0_18px_40px_-12px_rgba(242,183,5,0.8)] transition hover:scale-[1.03] active:scale-95"
                >
                  ابدأ القيادة
                </button>
                <div className="mt-5 flex flex-wrap items-center justify-center gap-2 text-[11px] text-paper/60">
                  <Key>←</Key>
                  <Key>→</Key>
                  <span>أو</span>
                  <Key>A</Key>
                  <Key>D</Key>
                  <span>للمناورة ·</span>
                  <Key>P</Key>
                  <span>إيقاف ·</span>
                  <Key>R</Key>
                  <span>إعادة ·</span>
                  <span>اسحب باللمس للتحكّم</span>
                </div>
              </div>
            )}

            {phase === "paused" && (
              <div className="pop w-full max-w-sm text-center">
                <h3 className="font-display text-4xl text-paper">إيقاف مؤقت</h3>
                <p className="mt-2 text-sm text-paper/70">الشارع ينتظر عودتك.</p>
                <div className="mt-6 flex justify-center gap-3">
                  <button
                    onClick={pauseGame}
                    className="rounded-full bg-road-yellow px-7 py-3 font-bold text-ink transition hover:scale-105"
                  >
                    متابعة
                  </button>
                  <button
                    onClick={startGame}
                    className="rounded-full border border-white/20 px-7 py-3 font-bold text-paper transition hover:border-road-yellow"
                  >
                    إعادة القيادة
                  </button>
                </div>
              </div>
            )}

            {phase === "over" && (
              <div className="pop w-full max-w-lg text-center">
                <div className="tracked text-[10px] text-sign-red">انتهت الرحلة</div>
                <h3 className="font-display text-5xl leading-tight text-paper">
                  اصطدام! السيارة تنتظرك
                </h3>
                <div className="mt-5 flex items-stretch justify-center gap-3">
                  <Stat label="النقاط" value={lastRun?.score ?? 0} accent />
                  <Stat label="المسافة" value={`${lastRun?.distance ?? 0} م`} />
                  <Stat label="اللافتات" value={lastRun?.collected ?? 0} />
                </div>
                {roundRewards && roundRewards.awarded.length > 0 && (
                  <div className="mx-auto mt-5 max-w-md rounded-2xl border border-road-yellow/30 bg-road-yellow/10 p-4 text-right">
                    <div className="tracked text-[9px] text-road-yellow">
                      مكاسب اختبار القيادة
                    </div>
                    <ul className="mt-2 space-y-1 text-[12px] text-paper/85">
                      {roundRewards.awarded.map((a) => (
                        <li key={a.key} className="flex items-center justify-between gap-3">
                          <span>{a.label}</span>
                          <span className="tnum text-road-yellow">+1 نقطة</span>
                        </li>
                      ))}
                    </ul>
                    <div className="mt-2 text-[11px] text-paper/60">
                      رصيدك الآن{" "}
                      <span className="tnum text-road-yellow">{roundRewards.points}</span> نقطة
                      {roundRewards.newUnlocks.length > 0 &&
                        ` — فُتحت خانة ${roundRewards.newUnlocks[0].tier}: ${roundRewards.newUnlocks[0].carName}`}
                    </div>
                  </div>
                )}
                <div className="mt-6 flex flex-wrap justify-center gap-3">
                  <button
                    onClick={startGame}
                    className="rounded-full bg-road-yellow px-8 py-3.5 font-bold text-ink shadow-[0_18px_40px_-12px_rgba(242,183,5,0.7)] transition hover:scale-105 active:scale-95"
                  >
                    إعادة فورية (R)
                  </button>
                  <button
                    onClick={() => {
                      phaseRef.current = "ready";
                      setPhase("ready");
                    }}
                    className="rounded-full border border-white/20 px-8 py-3.5 font-bold text-paper transition hover:border-road-yellow"
                  >
                    القائمة
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* أزرار اللمس */}
      <div className="mt-4 flex items-center justify-between gap-3 md:hidden">
        <button
          {...hold("left")}
          aria-label="يسار"
          className="h-16 flex-1 rounded-2xl border border-ink/15 bg-ink/5 text-2xl font-bold text-ink active:bg-road-yellow"
        >
          ←
        </button>
        <button
          onClick={phase === "playing" ? pauseGame : startGame}
          className="h-16 rounded-2xl bg-ink px-6 text-sm font-bold text-paper"
        >
          {phase === "playing" ? "إيقاف" : "ابدأ"}
        </button>
        <button
          {...hold("right")}
          aria-label="يمين"
          className="h-16 flex-1 rounded-2xl border border-ink/15 bg-ink/5 text-2xl font-bold text-ink active:bg-road-yellow"
        >
          →
        </button>
      </div>

      {/* لوحة النتائج */}
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <ScoreBoard title="أفضل نتائجك (محليًا)" rows={localScores.map((s) => ({ name: s.name, score: s.score }))} />
        <ScoreBoard
          title="لوحة الأبطال (الخادم)"
          rows={serverScores.map((s) => ({ name: s.playerName, score: s.score }))}
          empty="لا توجد نتائج بعد — كن أول سائق يُسجّل."
        />
      </div>
    </div>
  );
}

function Key({ children }: { children: React.ReactNode }) {
  return (
    <kbd className="rounded-md border border-white/20 bg-white/10 px-2 py-1 font-mono text-[11px] text-paper">
      {children}
    </kbd>
  );
}

function Stat({ label, value, accent }: { label: string; value: React.ReactNode; accent?: boolean }) {
  return (
    <div
      className={`min-w-[96px] rounded-2xl border px-5 py-3 ${
        accent ? "border-road-yellow/40 bg-road-yellow/10" : "border-white/12 bg-white/5"
      }`}
    >
      <div className="tracked text-[9px] text-paper/60">{label}</div>
      <div className={`tnum text-2xl font-semibold ${accent ? "text-road-yellow" : "text-paper"}`}>
        {value}
      </div>
    </div>
  );
}

function ScoreBoard({
  title,
  rows,
  empty = "لم تُسجَّل نتائج بعد.",
}: {
  title: string;
  rows: { name: string; score: number }[];
  empty?: string;
}) {
  return (
    <div className="rounded-2xl border border-ink/12 bg-paper-2/70 p-5">
      <h4 className="tracked mb-3 text-[10px] text-warm-2">{title}</h4>
      {rows.length === 0 ? (
        <p className="text-sm text-warm-2">{empty}</p>
      ) : (
        <ol className="divide-y divide-ink/10">
          {rows.slice(0, 5).map((r, i) => (
            <li key={`${r.name}-${i}`} className="flex items-center gap-3 py-2">
              <span
                className={`tnum flex h-7 w-7 items-center justify-center rounded-full text-xs font-semibold ${
                  i === 0 ? "bg-sign-red text-paper" : "bg-ink/10 text-ink"
                }`}
              >
                {i + 1}
              </span>
              <span className="flex-1 truncate text-sm">{r.name}</span>
              <span className="tnum text-sm font-semibold">{r.score.toLocaleString("en-US")}</span>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}
