type Kind =
  | "warn"
  | "stop"
  | "yield"
  | "no"
  | "must"
  | "info"
  | "belt"
  | "speed";

/** لافتات مرور مرسومة يدويًا كـ SVG — أشكال هندسية صارمة كما في لوحات الطريق. */
export function Sign({
  kind,
  className = "",
  size = 72,
}: {
  kind: Kind;
  className?: string;
  size?: number;
}) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 100 100",
    className,
    "aria-hidden": true as const,
  };

  switch (kind) {
    case "warn":
      return (
        <svg {...common}>
          <path
            d="M50 6 L96 88 H4 Z"
            fill="#F7F3EA"
            stroke="#C8102E"
            strokeWidth="11"
            strokeLinejoin="round"
          />
          <path
            d="M50 34 V58"
            stroke="#15181B"
            strokeWidth="10"
            strokeLinecap="round"
          />
          <circle cx="50" cy="72" r="6" fill="#15181B" />
        </svg>
      );
    case "stop":
      return (
        <svg {...common}>
          <path
            d="M31 4 H69 L96 31 V69 L69 96 H31 L4 69 V31 Z"
            fill="#C8102E"
            stroke="#F7F3EA"
            strokeWidth="4"
            strokeLinejoin="round"
          />
          <text
            x="50"
            y="58"
            textAnchor="middle"
            dominantBaseline="middle"
            fill="#FFFFFF"
            fontSize="30"
            fontWeight="700"
            fontFamily="var(--font-display)"
          >
            قف
          </text>
        </svg>
      );
    case "yield":
      return (
        <svg {...common}>
          <path
            d="M8 12 H92 L50 92 Z"
            fill="#F7F3EA"
            stroke="#C8102E"
            strokeWidth="11"
            strokeLinejoin="round"
          />
          <path
            d="M26 34 H74"
            stroke="#C8102E"
            strokeWidth="7"
            strokeLinecap="round"
          />
        </svg>
      );
    case "no":
      return (
        <svg {...common}>
          <circle cx="50" cy="50" r="43" fill="#F7F3EA" stroke="#C8102E" strokeWidth="11" />
          <path
            d="M50 26 V64 M50 64 L36 52 M50 64 L64 52"
            stroke="#15181B"
            strokeWidth="9"
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
          />
          <path
            d="M22 78 L78 22"
            stroke="#C8102E"
            strokeWidth="9"
            strokeLinecap="round"
          />
        </svg>
      );
    case "must":
      return (
        <svg {...common}>
          <circle cx="50" cy="50" r="43" fill="#1B4C8C" />
          <path
            d="M50 76 V32 M50 28 L34 46 M50 28 L66 46"
            stroke="#FFFFFF"
            strokeWidth="10"
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
            transform="rotate(180 50 50)"
          />
        </svg>
      );
    case "info":
      return (
        <svg {...common}>
          <rect x="8" y="8" width="84" height="84" rx="8" fill="#1B4C8C" />
          <text
            x="50"
            y="58"
            textAnchor="middle"
            dominantBaseline="middle"
            fill="#FFFFFF"
            fontSize="52"
            fontWeight="700"
            fontFamily="var(--font-mono)"
          >
            P
          </text>
        </svg>
      );
    case "belt":
      return (
        <svg {...common}>
          <circle cx="50" cy="50" r="43" fill="#F7F3EA" stroke="#C8102E" strokeWidth="11" />
          <path
            d="M28 24 C40 42 52 58 60 78"
            stroke="#15181B"
            strokeWidth="9"
            strokeLinecap="round"
            fill="none"
          />
          <rect x="52" y="58" width="22" height="18" rx="4" fill="#C8102E" />
          <path d="M24 76 H44" stroke="#15181B" strokeWidth="9" strokeLinecap="round" />
        </svg>
      );
    case "speed":
    default:
      return (
        <svg {...common}>
          <circle cx="50" cy="50" r="43" fill="#F7F3EA" stroke="#C8102E" strokeWidth="11" />
          <text
            x="50"
            y="58"
            textAnchor="middle"
            dominantBaseline="middle"
            fill="#15181B"
            fontSize="38"
            fontWeight="700"
            fontFamily="var(--font-mono)"
          >
            60
          </text>
        </svg>
      );
  }
}

/** شعار التطبيق: مقود + طريق، مرسوم كمسارات. */
export function Logo({ className = "", size = 44 }: { className?: string; size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      className={className}
      role="img"
      aria-label="مرآب السائق المحترف"
    >
      <circle cx="50" cy="50" r="46" fill="#15181B" />
      <circle
        cx="50"
        cy="50"
        r="31"
        fill="none"
        stroke="#F2B705"
        strokeWidth="8"
      />
      <circle cx="50" cy="50" r="10" fill="#C8102E" />
      <path
        d="M50 19 V40 M22 62 L41 51 M78 62 L59 51"
        stroke="#F2B705"
        strokeWidth="8"
        strokeLinecap="round"
      />
    </svg>
  );
}
