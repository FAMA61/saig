"use client";

import { useEffect, useState } from "react";
import { POINTS_EVENT, type PointsEvent } from "@/lib/achievements";

export default function PointsChip({ initial }: { initial: number }) {
  const [points, setPoints] = useState(initial);
  const [pulse, setPulse] = useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent<PointsEvent>).detail;
      if (detail?.points !== undefined) {
        setPoints(detail.points);
        setPulse(true);
        window.setTimeout(() => setPulse(false), 900);
      }
    };
    window.addEventListener(POINTS_EVENT, handler);
    return () => window.removeEventListener(POINTS_EVENT, handler);
  }, []);

  return (
    <div
      className={`flex items-center gap-2 rounded-full border border-ink/12 bg-ink px-4 py-2 text-paper transition ${
        pulse ? "scale-110 border-road-yellow" : ""
      }`}
    >
      <span className="h-2 w-2 rounded-full bg-road-yellow" />
      <span className="tnum text-sm font-semibold">{points}</span>
      <span className="text-[11px] text-paper/60">نقطة</span>
    </div>
  );
}
