import Link from "next/link";
import Game from "@/components/Game";
import Learn, { type InitialState } from "@/components/Learn";
import Docs from "@/components/Docs";
import { Logo, Sign } from "@/components/Signs";
import PointsChip from "@/components/PointsChip";
import { getState } from "@/lib/store";
import { LESSONS, POINT_THRESHOLD } from "@/lib/lessons";
import { GARAGE_SLOTS, POINTS_PER_GARAGE_SLOT } from "@/lib/constants";

export const dynamic = "force-dynamic";

const fallback: InitialState = { points: 0, lessonsDone: 0, progress: [], rewards: [] };

async function loadState(): Promise<InitialState> {
  try {
    const s = await getState();
    return {
      points: s.player.points,
      lessonsDone: s.player.lessonsDone,
      progress: s.progress.map((p) => ({
        lessonId: p.lessonId,
        bestPct: p.bestPct,
        attempts: p.attempts,
        completed: p.completed,
        pointAwarded: p.pointAwarded,
      })),
      rewards: s.rewards.map((r) => ({ tier: r.tier, carName: r.carName })),
    };
  } catch (err) {
    console.error("failed to load state", err);
    return fallback;
  }
}

export default async function Home() {
  const state = await loadState();

  return (
    <main className="relative">
      {/* ── الشريط العلوي ── */}
      <header className="sticky top-0 z-50 border-b border-ink/10 bg-paper/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-[1180px] items-center gap-4 px-5 py-3">
          <Link href="#top" className="flex items-center gap-3">
            <Logo size={38} />
            <div>
              <div className="font-display text-lg leading-none text-ink">مرآب السائق المحترف</div>
              <div className="tracked text-[8px] text-warm-2">Driving Academy · Gamified</div>
            </div>
          </Link>

          <nav className="mr-auto hidden items-center gap-6 text-[13px] text-warm-2 md:flex">
            <a href="#game" className="transition hover:text-ink">اللعبة</a>
            <a href="#learn" className="transition hover:text-ink">الدروس</a>
            <a href="#garage" className="transition hover:text-ink">المرآب</a>
            <a href="#docs" className="transition hover:text-ink">التوثيق</a>
          </nav>

          <div className="mr-auto flex items-center gap-2 md:mr-0">
            <PointsChip initial={state.points} />
            <a
              href="#game"
              className="rounded-full bg-sign-red px-5 py-2.5 text-[13px] font-bold text-paper transition hover:scale-105"
            >
              العب الآن
            </a>
          </div>
        </div>
      </header>

      {/* ── الواجهة ── */}
      <section id="top" className="relative overflow-hidden bg-asphalt">
        <img
          src="images/asphalt.jpg"
          alt="طريق إسفلتي ليلي بخطوط صفراء"
          className="absolute inset-0 h-full w-full object-cover opacity-55"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-asphalt via-asphalt/80 to-asphalt/45" />

        <div className="relative mx-auto max-w-[1180px] px-5 pb-16 pt-20 sm:pb-24 sm:pt-28">
          <div className="flex items-center gap-3">
            <Sign kind="warn" size={38} />
            <Sign kind="stop" size={38} />
            <Sign kind="yield" size={38} />
            <span className="tracked mr-2 text-[10px] text-road-yellow">
              رخصة السياقة · تعلّم · العب · افوز
            </span>
          </div>

          <h1 className="mt-7 max-w-4xl font-display text-[clamp(2.6rem,8vw,6.2rem)] leading-[1.08] text-paper">
            تعلّم القواعد، اجمع النقاط،
            <span className="block text-road-yellow">وقُد السيارة الأسطورية.</span>
          </h1>

          <p className="mt-7 max-w-2xl text-[16px] leading-9 text-paper/80">
            مدرسة سياقة مُلعّبة بالكامل: 6 دروس مصوّرة بلافتات مرور حقيقية، 30 سؤالًا
            امتحانيًا، ولعبة شارع بـ 60 إطارًا في الثانية. كل اختبار تُجتازه بنسبة أعلى من{" "}
            <strong className="text-road-yellow">{POINT_THRESHOLD}%</strong> يمنحك نقطة، وكل{" "}
            <strong className="text-road-yellow">{POINTS_PER_GARAGE_SLOT}</strong> نقاط تفتح لك
            خانة في مرآب السيارات الفخمة.
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-3">
            <a
              href="#game"
              className="rounded-full bg-road-yellow px-8 py-4 text-[15px] font-bold text-ink shadow-[0_22px_55px_-16px_rgba(242,183,5,0.85)] transition hover:scale-[1.04] active:scale-95"
            >
              ابدأ القيادة خلال 10 ثوانٍ
            </a>
            <a
              href="#learn"
              className="rounded-full border border-white/25 px-8 py-4 text-[15px] font-bold text-paper transition hover:border-road-yellow hover:text-road-yellow"
            >
              إلى المكتبة والدروس
            </a>
          </div>

          <dl className="mt-14 grid max-w-3xl grid-cols-2 gap-x-8 gap-y-6 border-t border-white/12 pt-8 sm:grid-cols-4">
            {[
              ["6", "دروس مصوّرة"],
              ["30", "سؤالًا امتحانيًا"],
              [`${GARAGE_SLOTS}`, "خانات مرآب"],
              [`${POINT_THRESHOLD}%+`, "شرط كسب النقطة"],
            ].map(([v, l]) => (
              <div key={l}>
                <dt className="tnum text-4xl font-semibold text-road-yellow">{v}</dt>
                <dd className="mt-1 text-[12px] text-paper/65">{l}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      {/* ── شريط القواعد ── */}
      <section className="border-b border-ink/10 bg-paper-2/60">
        <div className="mx-auto grid max-w-[1180px] gap-6 px-5 py-10 sm:grid-cols-3">
          {[
            {
              t: "الدروس والاختبارات",
              d: "شرح مبسّط للافتات التحذير والمنع والإلزام، وأولوية التقاطعات، والسرعة الآمنة — مع اختبار فوري بعد كل درس.",
              k: "info" as const,
            },
            {
              t: "نظام النقاط",
              d: `أي نتيجة أعلى من ${POINT_THRESHOLD}% تُسجّل لك نقطة واحدة تُحفظ في قاعدة البيانات مع سجلّ مفصّل.`,
              k: "must" as const,
            },
            {
              t: "المرآب الفاخر",
              d: `كل ${POINTS_PER_GARAGE_SLOT} نقاط تفتح خانة جديدة، وتفتح السيارة حوارًا تفاعليًا: «هل أنت ستسوقني؟»`,
              k: "yield" as const,
            },
          ].map((f) => (
            <div key={f.t} className="flex gap-4">
              <div className="shrink-0">
                <Sign kind={f.k} size={52} />
              </div>
              <div>
                <h3 className="font-display text-2xl leading-snug text-ink">{f.t}</h3>
                <p className="mt-2 text-[13.5px] leading-7 text-warm-2">{f.d}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── اللعبة ── */}
      <section id="game" className="relative scroll-mt-20 bg-asphalt py-16">
        <div className="mx-auto max-w-[1180px] px-5">
          <div className="mb-8 flex flex-wrap items-end justify-between gap-5">
            <div>
              <div className="tracked text-[10px] text-road-yellow">لعبة الشارع · 60 FPS</div>
              <h2 className="mt-2 font-display text-5xl leading-tight text-paper sm:text-6xl">
                أمسك المقود
              </h2>
              <p className="mt-4 max-w-xl text-[15px] leading-8 text-paper/70">
                تحكّم بالأسهم أو بالسحب على الشاشة، اجمع لافتات المرور لرفع المضاعِف حتى ×5،
                وتجنّب الحواجز. اهتزاز الشاشة والشرر والوميض عند كل اصطدام — والنتيجة تُحفظ
                مباشرة في لوحة الأبطال، وكل مستوى تُجتازه من <strong className="text-road-yellow">اختبارات القيادة</strong>{" "}
                يمنحك نقطة حقيقية في مرآبك.
              </p>
            </div>
            <div className="flex items-center gap-3 rounded-2xl border border-white/12 px-5 py-4 text-paper/75">
              <div>
                <div className="tracked text-[9px] text-road-yellow">التحكّم</div>
                <div className="mt-1 text-[12px]">← → · A D · سحب اللمس · P إيقاف · R إعادة</div>
              </div>
            </div>
          </div>

          <Game />
        </div>
      </section>

      {/* ── الدروس + المرآب ── */}
      <section id="learn" className="relative scroll-mt-20 py-16">
        <div className="mx-auto max-w-[1180px] px-5">
          <Learn initial={state} />
        </div>
      </section>

      {/* ── التوثيق ── */}
      <section className="scroll-mt-20 border-t border-ink/10 bg-paper-2/50 py-16">
        <div className="mx-auto max-w-[1180px] px-5">
          <Docs />
        </div>
      </section>

      {/* ── التذييل ── */}
      <footer className="relative overflow-hidden bg-asphalt">
        <img
          src="images/dawn-road.jpg"
          alt="طريق عند الفجر"
          className="absolute inset-0 h-full w-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-asphalt via-asphalt/85 to-asphalt/60" />
        <div className="relative mx-auto max-w-[1180px] px-5 py-16">
          <div className="flex flex-wrap items-start justify-between gap-10">
            <div className="max-w-md">
              <div className="flex items-center gap-3">
                <Logo size={40} />
                <div className="font-display text-2xl text-paper">مرآب السائق المحترف</div>
              </div>
              <p className="mt-5 text-[13.5px] leading-8 text-paper/70">
                تطبيق تعليمي تفاعلي يجمع بين الدروس النظريّة واللعب المُحفِّز، لمساعدة
                المترشّحين على اجتياز امتحان رخصة السياقة بنجاح — وبروح المتعة.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-x-12 gap-y-3 text-[13px] text-paper/70">
              <a href="#game" className="transition hover:text-road-yellow">لعبة الشارع</a>
              <a href="#learn" className="transition hover:text-road-yellow">الدروس</a>
              <a href="#garage" className="transition hover:text-road-yellow">المرآب</a>
              <a href="#docs" className="transition hover:text-road-yellow">التوثيق التقني</a>
              <a href="#top" className="transition hover:text-road-yellow">أعلى الصفحة</a>
            </div>
          </div>

          <div className="mt-12 flex flex-wrap items-center justify-between gap-4 border-t border-white/12 pt-6 text-[11px] text-paper/45">
            <span>
              {LESSONS.length} دروس · 30 سؤالًا · {GARAGE_SLOTS} خانات · مبني بـ Next.js +
              PostgreSQL + Drizzle
            </span>
            <span className="tnum">© 2026 — صُمم لخدمة المترشّحين العرب</span>
          </div>
        </div>
      </footer>
    </main>
  );
}
