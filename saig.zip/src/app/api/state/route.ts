import { NextResponse } from "next/server";
import { getState } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const state = await getState();
    return NextResponse.json(state);
  } catch (err) {
    console.error("state error", err);
    return NextResponse.json({ error: "database_unavailable" }, { status: 503 });
  }
}
