import { NextResponse } from "next/server";
import { submitGameScore, topScores } from "@/lib/store";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    return NextResponse.json({ scores: await topScores(8) });
  } catch (err) {
    console.error("scores error", err);
    return NextResponse.json({ error: "database_unavailable" }, { status: 503 });
  }
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      playerName?: string;
      score?: number;
      distance?: number;
      tokens?: number;
    };
    const score = Number(body.score ?? 0);
    if (!Number.isFinite(score) || score < 0) {
      return NextResponse.json({ error: "bad_score" }, { status: 400 });
    }
    const row = await submitGameScore({
      playerName: String(body.playerName ?? "سائق"),
      score,
      distance: Number(body.distance ?? 0),
      tokens: Number(body.tokens ?? 0),
    });
    return NextResponse.json({ row, scores: await topScores(8) });
  } catch (err) {
    console.error("score submit error", err);
    return NextResponse.json({ error: "database_unavailable" }, { status: 503 });
  }
}
