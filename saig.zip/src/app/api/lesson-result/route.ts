import { NextResponse } from "next/server";
import { recordLessonResult } from "@/lib/store";
import { LESSONS } from "@/lib/lessons";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { lessonId?: string; correct?: number; total?: number };
    const lesson = LESSONS.find((l) => l.id === body.lessonId);
    if (!lesson) return NextResponse.json({ error: "unknown_lesson" }, { status: 400 });
    const total = Number(body.total ?? lesson.questions.length);
    const correct = Number(body.correct ?? 0);
    if (!Number.isFinite(correct) || correct < 0 || correct > total) {
      return NextResponse.json({ error: "bad_score" }, { status: 400 });
    }
    const result = await recordLessonResult(lesson.id, correct, total);
    return NextResponse.json(result);
  } catch (err) {
    console.error("lesson result error", err);
    return NextResponse.json({ error: "database_unavailable" }, { status: 503 });
  }
}
