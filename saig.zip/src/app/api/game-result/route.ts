import { NextResponse } from "next/server";
import { awardDrivePoints, topScores } from "@/lib/store";
import { evaluateRun } from "@/lib/achievements";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      score?: number;
      distance?: number;
      tokens?: number;
      seconds?: number;
    };
    const run = {
      score: Math.max(0, Number(body.score ?? 0)),
      distance: Math.max(0, Number(body.distance ?? 0)),
      tokens: Math.max(0, Number(body.tokens ?? 0)),
      seconds: Math.max(0, Number(body.seconds ?? 0)),
    };
    const earned = evaluateRun(run);
    const result = await awardDrivePoints(earned);
    return NextResponse.json({ ...result, earned, scores: await topScores(8) });
  } catch (err) {
    console.error("game result error", err);
    return NextResponse.json({ error: "database_unavailable" }, { status: 503 });
  }
}
