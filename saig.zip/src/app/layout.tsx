import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Amiri, Tajawal, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";

const amiri = Amiri({
  subsets: ["arabic", "latin"],
  weight: ["400", "700"],
  variable: "--font-amiri",
  display: "swap",
});

const tajawal = Tajawal({
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "700", "800"],
  variable: "--font-tajawal",
  display: "swap",
});

const plex = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-plex",
  display: "swap",
});

export const metadata: Metadata = {
  title: "مرآب السائق المحترف — مدرسة السياقة المُلعّبة",
  description:
    "تطبيق تعليمي تفاعلي لرخصة السياقة: دروس، اختبارات، نقاط، مرآب سيارات فخمة، ولعبة شارع بـ 60 إطارًا في الثانية.",
  keywords: ["رخصة السياقة", "قوانين المرور", "إشارات المرور", "تعلم السياقة"],
};

export const viewport: Viewport = {
  themeColor: "#12151A",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="ar"
      dir="rtl"
      className={`${amiri.variable} ${tajawal.variable} ${plex.variable}`}
    >
      <body>{children}</body>
    </html>
  );
}
